#!/bin/bash

cd oss
make clean all
cd ..
cd mikmod
make clean all
cd ..
cd vorbis
make clean all
cd ..
cd adplug
make clean all
cd ..
cd spcplay
make clean all
cd ..

mkdir -p ~/.mikmod/plugins
cp -v *.so ~/.mikmod/plugins
