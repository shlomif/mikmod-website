/*
 * Input plugin for sid tunes using sidplay2
 * 
 * Written by Raphael Assenat, greatly inspired from xmms-sid
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "plugin.h"
#include "plugin_manager.h"
#include "file_info.h"
#include <sidplay/sidplay2.h>
#include <sidplay/builders/resid.h>

extern "C" {
	int plugin_in_init();
	void plugin_in_shutdown();
	int plugin_in_testFile(char *);
	int plugin_in_setFile(char *);
	int plugin_in_play(void);
	void plugin_in_update(void);
	void plugin_in_stop(void);
	int plugin_in_isStopped(void);
	void plugin_in_togglePause(void);
	int plugin_in_isPaused(void);
	char *plugin_in_getName(void);
	char *plugin_in_getAbout(void);
	char **plugin_in_listFileExts(void);
	MikMood_FileInfo *plugin_in_getFileInfo(void);
};

static char *fileexts[] = { "sid", NULL };

static int playing = 0;
static int paused = 0;

#define BUFFER_SIZE 44100
static unsigned char buffer[BUFFER_SIZE];

static MikMood_FileInfo *fi=NULL;
static MikMood_OutputPlugin *outp = NULL;
static AudioFMT g_fmt;

static sidplay2 *g_engine = NULL;
static sid2_config_t g_engine_config;
static SidTune *g_tune = NULL;
static sidbuilder *g_builder = NULL;

int plugin_in_init()
{

	playing = 0;
	paused = 0;

	/* create emulation engine */
	g_engine = new sidplay2;
	if (!g_engine) {
		printf("Failed to create engine\n");
		return -1;
	}

	/* Init builder */
	ReSIDBuilder *tmpb = new ReSIDBuilder("builder");
//	tmpb->create(g_engine->info().maxsids);
	g_builder = tmpb;

	return 0;
}

void plugin_in_shutdown()
{
	if (fi) { FI_free(fi); fi = NULL; }
	if (g_engine) { delete g_engine; }
	if (g_tune) { delete g_tune; }
}

int plugin_in_testFile(char *filename)
{
	SidTune *testTune = new SidTune(filename);

	if (!testTune) { return 0; }
	if (!testTune->getStatus())
	{
		delete testTune;
		return 0;
	}
	
	delete testTune;
	return 1;
}

int plugin_in_setFile(char *filename)
{
	if (fi) { FI_free(fi); }
	if (g_tune) { delete g_tune; }

	playing = 0;
	paused = 0;

	g_engine_config = g_engine->config();

	g_engine_config.clockDefault = SID2_CLOCK_CORRECT;
	g_engine_config.clockForced = 0;
	g_engine_config.clockSpeed = SID2_CLOCK_PAL; // SID2_CLOCK_NTSC
	g_engine_config.environment = sid2_envR;
	g_engine_config.forceDualSids = 0;
	g_engine_config.emulateStereo = 0;
	g_engine_config.frequency = 44100;
	g_engine_config.optimisation = 0;
	g_engine_config.playback = sid2_mono;
	g_engine_config.precision = 16;
	g_engine_config.sidDefault = SID2_MODEL_CORRECT;
	g_engine_config.sidEmulation = g_builder;
	g_engine_config.sidModel = g_engine_config.sidDefault;
	g_engine_config.sidSamples = 1;
	
	g_engine_config.sampleFormat = SID2_LITTLE_SIGNED;

	if (g_engine->config(g_engine_config) < 0)
	{
		printf("Configuration failed\n");
	}

	g_fmt.format = AUDIO_FORMAT_16_S;
	g_fmt.stereo = 0;
	g_fmt.sample_rate = 44100;


	printf("loading %s\n", filename);
	g_tune = new SidTune(filename);
	if (!g_tune) {
		return -1;
	}

	g_engine->load(g_tune);

	printf("ready\n");
	
	return 0;
}

int plugin_in_play(void)
{
	outp = PluginManager_getCurrentOutputPlugin();
	if (outp == NULL) { return 0; }

	outp->openAudio(&g_fmt);
	
	playing = 1;
	paused = 0;

	return 0;
}


void plugin_in_update(void)
{
	int samples_to_do;

	if (playing && !paused)
	{	
		samples_to_do = outp->getFree();
		if (samples_to_do * FMT_BYTES_PER_SAMPLE_C(&g_fmt) > BUFFER_SIZE )
		{
			samples_to_do = BUFFER_SIZE / FMT_BYTES_PER_SAMPLE_C(&g_fmt);
		}

		{
			int i;
			for (i=0; i<samples_to_do * FMT_BYTES_PER_SAMPLE_C(&g_fmt); i++)
			{
				printf("%02x ", buffer[i]);
			}
			printf("\n");
		}
		g_engine->play(buffer, samples_to_do * FMT_BYTES_PER_SAMPLE_C(&g_fmt));
		outp->writeAudio(buffer, samples_to_do);
	}
}

void plugin_in_stop(void)
{
	if (outp) {
		outp->closeAudio();
		outp = NULL;
	}
	playing = 0;
}

int plugin_in_isStopped(void)
{
	return !playing;
}

void plugin_in_togglePause(void)
{
	paused = !(paused);
}

int plugin_in_isPaused(void)
{
	return paused;
}

char *plugin_in_getName(void) { return "sidplay2"; }
char *plugin_in_getAbout(void) { return  "SID player using libsidplay2"; }
char **plugin_in_listFileExts(void) { return fileexts; }

MikMood_FileInfo *plugin_in_getFileInfo(void)
{	
	return fi;
}


