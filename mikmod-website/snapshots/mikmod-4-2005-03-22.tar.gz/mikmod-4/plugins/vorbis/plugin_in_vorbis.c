#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "plugin.h"
#include "plugin_manager.h"
#include "file_info.h"
#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>

static char *fileexts[] = { "ogg", NULL };

static OggVorbis_File vf;
static int vf_valid=0;

static vorbis_info *vi=NULL;
static vorbis_comment *cm=NULL;

static MikMood_FileInfo *fi=NULL;
static char fi_type[40];
static char *fi_comments = NULL;

static MikMood_OutputPlugin *g_outp = NULL;
static AudioFMT fmt;

static int playing=0;
static int stopped=1;

#define BUFFER_SIZE 44100
static unsigned char tmpbuf[BUFFER_SIZE];

static int fclose_dummy(void *datasource)
{
	return 0;
}

static size_t fread_stub(void *ptr, size_t size, size_t nmemb, void *datasource)
{
	return fread(ptr, size, nmemb, (FILE*)datasource);
}

static int fseek_stub(void *datasource, ogg_int64_t offset, int whence)
{
	return fseek((FILE*)datasource, offset, whence);
}

static long ftell_stub(void *datasource)
{
	return ftell((FILE*)datasource);
}

static ov_callbacks ov_cb;

static char *plugin_in_getName()
{
	return "ogg";
}

static char *plugin_in_getAbout()
{
	return "Ogg Vorbis input plugin using libvorbisfile";
}

static int plugin_in_init() { 
	ov_cb.read_func = fread_stub;
	ov_cb.seek_func = fseek_stub;
	ov_cb.close_func = fclose_dummy;
	ov_cb.tell_func = ftell_stub;
	return 0; 
}

static void plugin_in_shutdown() 
{
	if (fi) {
		FI_free(fi); fi = NULL;
	}
	if (vf_valid) {
		ov_clear(&vf);
		vf_valid = 0;
	}
	g_outp = NULL;
}

static int plugin_in_testFP(FILE *fp)
{
	OggVorbis_File tmpvf;
	fseek(fp, 0, SEEK_SET);
	if (ov_test_callbacks(fp, &tmpvf, NULL, 0, ov_cb)) {
		return 0; // false, not supported or error
	}
	ov_clear(&tmpvf);
	return 1;
}

static int plugin_in_setFP(FILE *fp)
{
	int i, total_len;
	char *d;
	
	fseek(fp, 0, SEEK_SET);
	if (ov_open(fp, &vf, NULL, 0)) {
		return 0; // error...
	}
	vf_valid = 1;	
	
	if (fi_comments) { free(fi_comments); }
	if (fi) { FI_free(fi); fi = NULL; }
	
	vi = ov_info(&vf, -1);
	
	fi = FI_create(-1, -1);
	fi->num_channels = vi->channels;
	fi->num_channels_in_use = fi->num_channels;
	snprintf(fi_type, 40, "Ogg Vorbis version %d", vi->version);

	cm = ov_comment(&vf, -1);
	
	/* calculate the space we need for all the comments */
	total_len = 0;
	for (i=0; i<cm->comments; i++) {
		total_len += cm->comment_lengths[i];
	}
	total_len += cm->comments; // for \n
	total_len += 1; // end

	/* alloc the string and copy comments from vorbis, adding new
	 * lines */
	fi_comments = malloc(total_len);
	d = fi_comments;	
	for (i=0; i<cm->comments; i++)
	{
		memcpy(d, cm->user_comments[i], cm->comment_lengths[i]);
		d += cm->comment_lengths[i];
		if (i == cm->comments-1) {
			*d = 0;
		} else {
			*d = '\n';
		}
		d++;
	}

	fi->type = fi_type;
	fi->title = "";
	fi->author = "";
	fi->comments = fi_comments;
	fi->sng_rate_type = "Bitrate";
	fi->sng_rate_unit = "kbps";
	
	fi->sng_rate.int_val = vi->bitrate_upper / 1024;
	fi->sng_rate.type = FI_VALUE_INT;
	
	/* setup audio parameters */
	fmt.format = AUDIO_FORMAT_16_LE_S;
	if (vi->channels>1) {
		fmt.stereo = 1;
	} else {
		fmt.stereo = 0;
	}
	fmt.sample_rate = vi->rate;
	//printf("ogg audio format stereo=%d rate=%d\n", fmt.stereo, fmt.sample_rate);
	
	playing = 0;
	stopped = 1;
	
	return 1;
}

static int plugin_in_play(MikMood_OutputPlugin *outp)
{
	g_outp = outp;

	if (g_outp==NULL ) { return 0; }

	g_outp->openAudio(&fmt);
	playing = 1;
	stopped = 0;

	return 1;
}

static void plugin_in_stop(void)
{
	if (g_outp==NULL ) { return; }
	
	g_outp->closeAudio();
	g_outp = NULL;
	
	playing = 0;
	stopped = 1;
//	if (ov_seekable(&vf)) {
//		ov_time_seek(&vf, 0);
//	}
}

static int plugin_in_isStopped(void) { return stopped; }

static void plugin_in_togglePause(void) {
	playing = !playing;
}

static int plugin_in_isPaused(void)
{
	if (stopped) { return 0; }
	return !playing;
}

static void plugin_in_update(void)
{
	long res;
	int must_do, done;
	int count=0;

	if (!playing || stopped) { return; }
	
	if (g_outp == NULL) { return; }

	/* get the number of samples we can write */
	must_do = g_outp->getFree();

	/* limit to buffer size and convert samples to bytes */
	if (must_do * FMT_BYTES_PER_SAMPLE_C(&fmt) > BUFFER_SIZE) {
		must_do = BUFFER_SIZE/FMT_BYTES_PER_SAMPLE_C(&fmt);
	}
	must_do *= FMT_BYTES_PER_SAMPLE_C(&fmt);

	if (must_do < 2) {
		return;
	}

	while (count<must_do)
	{

		res = ov_read(&vf, &tmpbuf[count], must_do-count, 0, 2, 1, NULL);
		switch(res)
		{
			case 0:
				stopped = 1;
				printf("End of file\n");
				return;
			case OV_HOLE:
			case OV_EBADLINK:
				printf("Decoding error...\n");
				/* todo: somehow warn the user about errors... */
				stopped = 1;
				return;
		}
		count += res;
	}	

	/* convert back to samples */
	done = count / FMT_BYTES_PER_SAMPLE_C(&fmt);
	
//	printf("Asked for %d bytes, got %d bytes (%d samples) [buffersize=%d] %d valid=%d\n", 
//			must_do, count, done, BUFFER_SIZE, p, vf_valid);
	g_outp->writeAudio(tmpbuf, done);
}

static MikMood_FileInfo *plugin_in_getFileInfo(void)
{
	fi->sng_rate.int_val = ov_bitrate_instant(&vf) / 1024;
	return fi;
}

static char **plugin_in_listFileExts(void)
{
	return fileexts;
}

static MikMood_InputPlugin plugin_in_vorbis = {
	plugin_in_getName,
	plugin_in_getAbout,
	plugin_in_init,
	plugin_in_shutdown,
	plugin_in_listFileExts,
	NULL, // testURL
	plugin_in_testFP,
	NULL, // testFile
	NULL, // setURL
	plugin_in_setFP,
	NULL, // setFile
	plugin_in_play,
	plugin_in_stop,
	plugin_in_isStopped,
	plugin_in_togglePause,
	plugin_in_isPaused,
	plugin_in_update,
	plugin_in_getFileInfo,
	NULL, // restart
	NULL, // ff
	NULL, // rew

	NULL, // getConfig
	NULL  // applyConfig
};

MikMood_InputPlugin *getInputPlugin(void) { return &plugin_in_vorbis; }

