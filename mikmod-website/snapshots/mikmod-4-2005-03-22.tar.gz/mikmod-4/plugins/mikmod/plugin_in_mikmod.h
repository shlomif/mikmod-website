#ifndef _plugin_in_mikmod_h__
#define _plugin_in_mikmod_h__

int Plugin_in_mikmod_register();

#endif // _plugin_in_mikmod_h__
