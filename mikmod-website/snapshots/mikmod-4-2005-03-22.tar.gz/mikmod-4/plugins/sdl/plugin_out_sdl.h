#ifndef _plugin_out_sdl_h__
#define _plugin_out_sdl_h__

int Plugin_out_sdl_register();

#endif // _plugin_out_sdl_h__


