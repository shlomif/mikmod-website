#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>
#include "plugin.h"
#include "plugin_manager.h"

static int out_sdl_init(void)
{
	return 0;
}

static int out_sdl_openAudio(AudioFMT *fmt)
{
	return 0;
}

static void out_sdl_closeAudio(void)
{
}

static void out_sdl_writeAudio(void *buf, int len)
{
}

static void out_sdl_flush(void)
{
}

static void out_sdl_pause(int paused)
{
}

static int out_sdl_getFree(void)
{
	return 0;
}

int Plugin_out_sdl_register(void)
{
	MikMood_OutputPlugin *out_sdl;

	out_sdl = malloc(sizeof(MikMood_OutputPlugin));
	if (out_sdl == NULL) { return -1; }

	out_sdl->name = "SDL audio output";
	out_sdl->about = "By Raphael Assenat";
	out_sdl->init = out_sdl_init;
	out_sdl->openAudio = out_sdl_openAudio;
	out_sdl->closeAudio = out_sdl_closeAudio;
	out_sdl->writeAudio = out_sdl_writeAudio;
	out_sdl->flush = out_sdl_flush;
	out_sdl->pause = out_sdl_pause;
	out_sdl->getFree = out_sdl_getFree;

	if (PluginManager_registerOutputPlugin(out_sdl))
	{
		free(out_sdl);
		return -1;
	}

	return 0;
}



