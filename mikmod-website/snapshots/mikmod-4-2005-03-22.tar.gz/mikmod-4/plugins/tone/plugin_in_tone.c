#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "plugin.h"
#include "plugin_manager.h"
#include "file_info.h"

static int playing = 0;
static int paused = 0;

static int _tone=440;

#define SAMPLES_BUF 44100
static short *buffer=NULL;

static double angle = 0.0;
static double inc = 0.01; // incrementation of angle per sample

static MikMood_FileInfo *fi=NULL;


int plugin_in_init()
{
	
	buffer = malloc(sizeof(short)*SAMPLES_BUF);
	if (buffer == NULL) { return -1; }


	 
	
	return 0;
}

void plugin_in_shutdown()
{
	if (buffer) { free(buffer); buffer = NULL; }
	if (fi) { 
		if (fi->title) {
			free(fi->title);
		}
		free(fi); fi = NULL; 
	}
}

int plugin_in_testURL(char *url)
{
	int len = strlen(url);
	int tone;
	char *end = NULL;

	if (strncasecmp(url, "tone://", 7)==0) {
		if (len<8) { return 0; }
		tone = strtol(&url[7], &end, 10);
		if (end == &url[7]) {
			return 0;
		}
		return 1;
	}
	return 0;
}

int plugin_in_setURL(char *url)
{
	int len = strlen(url);
	char *end = NULL;

	if (strncasecmp(url, "tone://", 7)==0) {
		if (len<8) { return 0; }
		_tone = strtol(&url[7], &end, 10);
		if (end == &url[7]) {
			return 0;
		}
		
		inc = ( (1.0/44100.0)*(M_PI*2.0)*(double)_tone);
//		printf("Tone: %d hz, inc: %f\n", _tone, inc);
		
		fi = FI_create(-1, -1);
		if (fi)
		{
			char title[256];
			sprintf(title, "%d hz Tone", _tone);
			if (fi->title) { free(fi->title); }
			fi->title = strdup(title);
			fi->sng_progress_type = "Samples";
			fi->sng_progress_max = -1; // infinite
		}
		
		return 1;
	}
	return 0;
}

int plugin_in_play(void)
{
	MikMood_OutputPlugin *outp=PluginManager_getCurrentOutputPlugin();
	AudioFMT fmt;
	
	if (outp==NULL) { return -1; }

	fmt.format = AUDIO_FORMAT_16_S;
	fmt.sample_rate = 44100;
	fmt.stereo = 0;
	outp->openAudio(&fmt);
	
	playing = 1;
	return 0;
}

void plugin_in_update(void)
{
	MikMood_OutputPlugin *outp=PluginManager_getCurrentOutputPlugin();
	int must_do, i;
	
	if (outp==NULL) { return; }
	
	must_do = outp->getFree();

	for (i=0; i<must_do; i++)
	{
		buffer[i] = (short)( sin(angle)*32767.0);
		angle += inc;
	}

//	printf("writing %d bytes\n", must_do);
	outp->writeAudio(buffer, must_do);
	fi->sng_progress += must_do;
//	printf("done\n");
}

void plugin_in_stop(void)
{
	MikMood_OutputPlugin *outp=PluginManager_getCurrentOutputPlugin();
	if (outp==NULL) { return; }
	outp->closeAudio();

	playing = 0;
}

int plugin_in_isStopped(void)
{
	return !playing;
}

void plugin_in_togglePause(void)
{
	paused = !(paused);
}

int plugin_in_isPaused(void)
{
	return paused;
}

char *plugin_in_getName(void) { return "Sinus tone generator"; }
char *plugin_in_getAbout(void) { return  "Simple tone generator: (tone://frequency)"; }

MikMood_FileInfo *plugin_in_getFileInfo(void)
{
	return fi;
}


