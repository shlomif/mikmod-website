/*  MikMod module player
	(c) 1998 - 2000 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
 
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: engine.h,v 1.8 2005/02/28 03:07:15 raph Exp $

  Threaded player functions

==============================================================================*/

#ifndef ENGINE_H
#define ENGINE_H

//#include <mikmod.h>
#include <stdio.h>
#include "types.h"
#include "file_info.h"

#if LIBMIKMOD_VERSION >= 0x030200
#define MAXVOICES 256
#endif

#if LIBMIKMOD_VERSION >= 0x030200
typedef struct {
	VOICEINFO vinfo[MAXVOICES];		/* Current status for all module voices */
	struct {
		unsigned long time;			/* Last time this structure was updated */
		UBYTE volamp;				/* Volume meter amplitude */
	} vstatus[MAXVOICES];			/* Dynamic voice status */
} MP_DATA;

/* Returns a copy of the actual playdata */
void MP_GetData (MP_DATA *data);
#endif

mm_bool EN_Init (void);
void EN_Shutdown(void);

/* find an input plugin supporting the FILE and
   prepare it to play */
mm_bool EN_setFP(FILE *fp);

/* find an input plugin supporting the URL and
   prepare it to play */
mm_bool EN_setURL(char *url);


mm_bool EN_setFile(char *filename);

/* find an input plugin that supports the file
   and return the title string. (must be freed) */
char *EN_getTitle(char *filename);

/* Start playing the previously set file or url */
void EN_Play (void);

/* MikMod_Update(), if threads are not used */
void EN_Update (void);
/* Removes the thread started by MP_Start() */
void EN_Stop (void);

/* Wrapper for Player_Active() */
mm_bool EN_Active (void);
/* Wrapper for Player_TogglePause() */
void EN_TogglePause (void);
/* Wrapper for Player_Paused() */
mm_bool EN_Paused (void);
/* Wrapper for Player_SetVolume() */
void EN_Volume (int vol);

MikMood_FileInfo *EN_getInfo(void);

void EN_Restart(void);
void EN_ff(char big);
void EN_rew(char big);
	
#endif /* ENGINE_H */
