#include <stdio.h>
#include <stdlib.h>
#include "plugin.h"

static PARAM *findParam(PLUGIN_CONFIG *cfg, const char *param_name, int type)
{
	int i;
	for (i=0; i<cfg->cnt_params; i++)
	{
		if (cfg->params[i].type == type)
		{
			if (strcmp(cfg->params[i].name, param_name)==0)
			{
				return &cfg->params[i];
			}
		}
	}
	return NULL;
}

int pluginConfig_copyParam(PLUGIN_CONFIG *dst, PLUGIN_CONFIG *src, const char *param_name)
{
	int i;
	PARAM *dst_param=NULL, *src_param=NULL;

	for (i=0; i<src->cnt_params; i++)
	{
		src_param = findParam(src, param_name, i);
		if (!src_param) { continue; }
	}
	if (!src_param) { return -1; }

	for (i=0; i<dst->cnt_params; i++)
	{
		dst_param = findParam(dst, param_name, i);	
		if (!dst_param) { continue; }
	}
	if (!dst_param) { return -1; }
	
	memcpy(dst_param, src_param, sizeof(PARAM));
	
	return 0;
}

int pluginConfig_setInt(PLUGIN_CONFIG *cfg, const char *param_name, int val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_RANGE);
	if (!p) { return -1; }

	p->range.value = val;
}

int pluginConfig_setBool(PLUGIN_CONFIG *cfg, const char *param_name, int val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_BOOLEAN);
	if (!p) { return -1; }

	p->boolean.value = val;
}

int pluginConfig_setString(PLUGIN_CONFIG *cfg, const char *param_name, char *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_STRING);
	if (!p) { return -1; }

	if (strlen(val)>=PCFG_STR_MAXLEN) { return -1; }
	
	strcpy(p->string.value, val);
}

int pluginConfig_getInt(PLUGIN_CONFIG *cfg, const char *param_name, int *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_RANGE);
	if (!p) { return -1; }

	*val = p->range.value;
	return 0;
}


int pluginConfig_getBool(PLUGIN_CONFIG *cfg, const char *param_name, int *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_BOOLEAN);
	if (!p) { return -1; }
	
	*val = p->boolean.value;
	return 0;
}

int pluginConfig_getString(PLUGIN_CONFIG *cfg, const char *param_name, char **val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_STRING);
	if (!p) { return -1; }
	
	*val = p->string.value;
	return 0;
}

int pluginConfig_addParam(PLUGIN_CONFIG *cfg, const char *param_name, int type)
{	
	if (cfg->cnt_params>=PCFG_MAX_PARAMS) {
		return -1;
	}
	
	if (strlen(param_name)>=PCFG_STR_MAXLEN) { return -1; }
	
	memset(&cfg->params[cfg->cnt_params], 0, sizeof(PARAM));
	strcpy(cfg->params[cfg->cnt_params].name, param_name);
	cfg->params[cfg->cnt_params].type = type;
	cfg->cnt_params++;

	return 0;
}

PLUGIN_CONFIG *pluginConfig_create(const char *plugin_name)
{
	PLUGIN_CONFIG *cfg;

	if (strlen(plugin_name)>=PCFG_STR_MAXLEN) { return NULL; }
	
	cfg = malloc(sizeof(PLUGIN_CONFIG));
	if (!cfg) { return NULL; }
	
	strcpy(cfg->plugin_name, plugin_name);
	cfg->cnt_params = 0;
	
	return cfg;
}

void pluginConfig_free(PLUGIN_CONFIG *pcfg)
{
	if (pcfg) { free(pcfg); }
}


