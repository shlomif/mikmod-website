#ifndef _convert_h__
#define _convert_h__

#include "audio_fmt.h"

typedef struct {
	AudioFMT *src_fmt;
	AudioFMT *dst_fmt;
	int max_samples;
	
	unsigned char *buf1;
	unsigned char *buf2;	

	unsigned char *result;
} AudioConverter;

AudioConverter *AudioConverter_create(AudioFMT *src_fmt, AudioFMT *dst_fmt, int max_samples);
void AudioConverter_free(AudioConverter *cnv);

unsigned char *AudioConverter_do(AudioConverter *cnv, unsigned char *dat, int num_samples);

	
void convert_mono16_to_stereo16(unsigned char *src, unsigned char *dst, int num_samples);

void convert_copy(unsigned char *src, unsigned char *dst, int num_samples, int bytes_per_sample);
void convert_copy16(unsigned char *src, unsigned char *dst, int num_samples);
void convert_copy8(unsigned char *src, unsigned char *dst, int num_samples);


void convert_u8_to_s8(unsigned char *src, unsigned char *dst, int num_samples);
void convert_u16_to_s16(unsigned char *src, unsigned char *dst, int num_samples);

void convert_s8_to_s32(unsigned char *src, unsigned char *dst, int num_samples);
void convert_s16_to_s32(unsigned char *src, unsigned char *dst,
		int num_samples);


void convert_mono_s32_to_stereo_s32(unsigned char *src, unsigned char *dst, int num_samples);
void convert_stereo_s32_to_mono_s32(unsigned char *src, unsigned char *dst, int num_samples);

void convert_s32_to_s16(unsigned char *src, unsigned char *dst, int num_samples);
void convert_s32_to_s8(unsigned char *src, unsigned char *dst, int num_samples);

void convert_s16_to_u16(unsigned char *src, unsigned char *dst, int num_samples);
void convert_s8_to_u8(unsigned char *src, unsigned char *dst, int num_samples);

void convert_16_swap_endian(unsigned char *src, unsigned char *dst, int num_samples);

#endif //_convert_h__


