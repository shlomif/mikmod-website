#ifndef _audio_fmt_h__
#define _audio_fmt_h__

#define AUDIO_FORMAT_8_S		0
#define AUDIO_FORMAT_8_U		1
#define AUDIO_FORMAT_16_S		2
#define AUDIO_FORMAT_16_LE_S	3
#define AUDIO_FORMAT_16_BE_S	4
#define AUDIO_FORMAT_16_U		5
#define AUDIO_FORMAT_16_LE_U	6
#define AUDIO_FORMAT_16_BE_U	7

/* for future */
#define AUDIO_FORMAT_24_S		8
#define AUDIO_FORMAT_24_LE_S	9
#define AUDIO_FORMAT_24_BE_S	10
#define AUDIO_FORMAT_24_U		11
#define AUDIO_FORMAT_24_LE_U	12
#define AUDIO_FORMAT_24_BE_U	13


#define AUDIO_FORMAT_32_S		14
#define AUDIO_FORMAT_32_LE_S	15
#define AUDIO_FORMAT_32_BE_S	16
#define AUDIO_FORMAT_32_U		17
#define AUDIO_FORMAT_32_LE_U	18
#define AUDIO_FORMAT_32_SE_U	19


/* returns the number of bytes needed for one sample */
#define FMT_BYTES_PER_SAMPLE(a) ( ((a)->format) > 13 ? 4 : ((a)->format) > 7 ? 3 : ((a)->format) > 1 ? 2 : 1   )

/* returns the number of channels */
#define FMT_NUM_CHANNELS(a)	((a)->stereo?2:1)

/* return the number of bytes needed for one sample, considering the number of channels (thus the C) */
#define FMT_BYTES_PER_SAMPLE_C(a) ( FMT_BYTES_PER_SAMPLE(a) * FMT_NUM_CHANNELS(a) )


typedef struct {
	unsigned char format;
	int sample_rate;
	int stereo;
} AudioFMT;


#endif // _audio_fmt_h__

