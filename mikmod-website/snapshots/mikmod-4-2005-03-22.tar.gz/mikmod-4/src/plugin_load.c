#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>

#include "plugin.h"
#include "plugin_manager.h"

#include "plugin_load.h"

static char *getStringDummy(void) { return ""; }

int load_plugins(char *dirname)
{
	DIR *dir = opendir(dirname);
	struct dirent *ent;
	struct stat st;
	int res;
	char file[256];
	
	if (dir == NULL) { return -1; }

	while ((ent=readdir(dir)))
	{
		snprintf(file, 256, "%s%s", dirname, ent->d_name);
		res = stat(file, &st);
		if (res<0) {
			perror("Stat");
			continue;
		}

		if (S_ISREG(st.st_mode)) 
		{
			char *f;
			if (strncasecmp("plugin_in", ent->d_name, 9)==0)
			{
				/* input plugin */
				load_input_plugin(file);
			}
			if (strncasecmp("plugin_out", ent->d_name, 10)==0)
			{
				/* load output plugin */
				load_output_plugin(file);
			}
		}

	}

	closedir(dir);

	PluginManager_updatePatterns();

	return 0;
}


/* load and register an output plugin */
int load_output_plugin(char *file)
{
	void *handle;
	MikMood_OutputPlugin *outp=NULL;
	
	outp = calloc(1, sizeof(MikMood_OutputPlugin));
	if (outp == NULL) { return -1; }

	handle = dlopen(file, RTLD_NOW);
	if (handle == NULL) { 
		fprintf(stderr, "failed to load plugin, %s\n", dlerror());
		free(outp);
		return -1; 
	}

	outp->dlhandle = handle;
	outp->getName = dlsym(handle, "plugin_out_getName");
	outp->getAbout = dlsym(handle, "plugin_out_getAbout");
	outp->init = dlsym(handle, "plugin_out_init");
	outp->openAudio = dlsym(handle, "plugin_out_openAudio");
	outp->closeAudio = dlsym(handle, "plugin_out_closeAudio");
	outp->writeAudio = dlsym(handle, "plugin_out_writeAudio");
	outp->flush = dlsym(handle, "plugin_out_flush");
	outp->pause = dlsym(handle, "plugin_out_pause");
	outp->getFree = dlsym(handle, "plugin_out_getFree");

	/* check for mandatory pointers */
	if (!outp->getName) { printf("Missing name symbol\n"); dlclose(handle); free(outp); return -1; }
	if (!outp->init) { printf("Missing init symbol\n"); dlclose(handle); free(outp); return -1; }
	if (!outp->openAudio) { printf("Missing openAudio symbol\n"); dlclose(handle); free(outp); return -1;}
	if (!outp->closeAudio) { printf("Missiong closeAudio symbol\n"); dlclose(handle); free(outp); return -1; }
	if (!outp->writeAudio) { printf("Missing writeAudio symbol\n"); dlclose(handle); free(outp); return -1; }
	if (!outp->pause) { printf("Missing pause symbol\n"); dlclose(handle); free(outp); return -1; }
	if (!outp->getFree) { printf("Missing getFree symbol\n"); dlclose(handle); free(outp); return -1; }
	
	PluginManager_registerOutputPlugin(outp);

	return 0;
}

/* load and register an input plugin */
int load_input_plugin(char *file)
{
	void *handle;
	MikMood_InputPlugin *inp=NULL;
	MikMood_InputPlugin *(*getP)(void);
	
	if (file == NULL) { 
		fprintf(stderr, "cannot load NULL filename\n");
		return -1; 
	}
	
	//inp = calloc(1, sizeof(MikMood_InputPlugin));
	//if (inp == NULL) { return -1; }

	handle = dlopen(file, RTLD_NOW);
	if (handle == NULL) { 
		fprintf(stderr, "failed to load plugin, %s\n", dlerror());
		return -1; 
	}

	getP = dlsym(handle, "getInputPlugin");
	if (getP == NULL) {
		fprintf(stderr, "Required getInputPlugin symbol not found (%s)", dlerror());
		return -1;	
	}
	inp = getP();
	
	inp->dlhandle = handle;

	/* check for mandatory pointers */
	if (!inp->getName) { printf("Missing name symbol\n"); dlclose(handle); free(inp); return -1; }
	if (!inp->testURL && !inp->testFP && !inp->testFile) { printf("Missing tests symbols\n"); dlclose(handle); free(inp); return -1; }
	if (inp->testURL && !inp->setURL) { printf("Missing setURL symbol\n"); dlclose(handle); free(inp); return -1; }
	if (inp->testFP && !inp->setFP) { printf("Missing setFP symbol\n") ;dlclose(handle); free(inp); return -1; }
	if (inp->testFile && !inp->setFile) { printf("Missing setFile symbol\n") ;dlclose(handle); free(inp); return -1; }
	if (!inp->play || !inp->stop || !inp->togglePause || !inp->update) { return -1; }
	if (!inp->isStopped || !inp->isPaused) { printf("Missing status symbols\n"); dlclose(handle); free(inp); return -1; }
	if (!inp->getFileInfo) { printf("Missing getFileInfo symbol\n"); dlclose(handle); free(inp); return -1; }

	if (!(inp->applyConfig && inp->getConfig)) {
		if ((inp->applyConfig || inp->getConfig)) {
			/* cannot support read only or write only config! */
			printf("Only one of the two symbols required for configuration found! Plugin will not be configurable.\n");			
			inp->applyConfig = NULL; inp->getConfig = NULL;
		}
	}

	if (!inp->getAbout) { inp->getAbout = getStringDummy; }

	PluginManager_registerInputPlugin(inp);
	
	return 0;
}



