#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "file_info.h"


MikMood_FileInfo *FI_create(int num_samples, int num_instruments)
{
	MikMood_FileInfo *fi = calloc(1, sizeof(MikMood_FileInfo));

	if (fi==NULL) { return NULL; }

	if (num_samples>0) {
		fi->sampleInfo = calloc(num_samples, sizeof(MikMood_SampleInfo));
		if (fi->sampleInfo == NULL) { FI_free(fi); return NULL; }
	}
	if (num_instruments>0) {
		fi->instrumentInfo = calloc(num_instruments, sizeof(MikMood_InstrumentInfo));
		if (fi->instrumentInfo == NULL) { FI_free(fi); return NULL; }
	}

	fi->num_samples = num_samples;
	fi->num_instruments = num_instruments;
	
	return fi;	
}

void FI_free(MikMood_FileInfo *fi)
{
	if (fi) { 
		if (fi->sampleInfo) { free(fi->sampleInfo); }
		if (fi->instrumentInfo) { free(fi->instrumentInfo); }
		free(fi); 
	}
}

void FI_dump(MikMood_FileInfo *fi)
{
	int i;
	
	if (fi)
	{
		if (fi->title) { printf("Title: %s\n", fi->title); }
		if (fi->author) { printf("Author: %s\n", fi->author); }
		if (fi->type) { printf("Type: %s\n", fi->type); }
		if (fi->sampleInfo) {
			printf("-- %d Samples:\n", fi->num_samples);
			for (i=0; i<fi->num_samples; i++) {
				printf("%3d: %s\n", i, fi->sampleInfo[i].name);
			}
		}
		if (fi->instrumentInfo) {
			printf("-- %d Instruments:\n", fi->num_instruments);
			for (i=0; i<fi->num_instruments; i++) {
				printf("%3d: %s\n", i, fi->instrumentInfo[i].name);
			}
		}
		if (fi->comments) {
			printf("-- Comments:\n");
			printf("%s\n", fi->comments);
		}
	}
}

void FI_getStatusLine(MikMood_FileInfo *fi, char *buf, int buf_size)
{
	char tmp_buf[32];
	int p = 0;

	buf[0] = 0;
	
	if (fi)
	{
		if (fi->sng_progress_type)
		{
			if (fi->sng_progress_max>0) {
				snprintf(tmp_buf, 32, "%s: %3d/%3d ", fi->sng_progress_type,
						fi->sng_progress, fi->sng_progress_max);
			} 
			else {
				snprintf(tmp_buf, 32, "%s: %3d ", fi->sng_progress_type,
						fi->sng_progress);
			}
			snprintf(&buf[p], buf_size-p, "%s", tmp_buf);
			p += strlen(tmp_buf); if (p>=buf_size) { return; }
		}
		if (fi->sng_subprogress_type)
		{
			if (fi->sng_subprogress_max>0) {
				snprintf(tmp_buf, 32, "%s: %3d/%3d ", fi->sng_subprogress_type,
						fi->sng_subprogress, fi->sng_subprogress_max);
			}
			else {
				snprintf(tmp_buf, 32, "%s: %02x ", fi->sng_subprogress_type,
						fi->sng_subprogress);
			}
			snprintf(&buf[p], buf_size-p, "%s", tmp_buf);
			p += strlen(tmp_buf); if (p>=buf_size) { return; }
		}
		if (fi->num_channels>0) {
			snprintf(tmp_buf, 32, "chn: %3d/%3d ", fi->num_channels_in_use, fi->num_channels);
			snprintf(&buf[p], buf_size-p, "%s", tmp_buf);
			p += strlen(tmp_buf); if (p>=buf_size) { return; }
		}
	}
}

void FI_dumpStatus(MikMood_FileInfo *fi)
{
	char buf[256];
	FI_getStatusLine(fi, buf, 256);
	printf("%s\r", buf); fflush(stdout);
}

