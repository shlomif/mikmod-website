#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "plugin_manager.h"
#include "plugin.h"
#include "mconfig.h"

static MikMood_InputPlugin *input_plugins=NULL;
static MikMood_OutputPlugin *output_plugins=NULL;

static char **FilePatterns = NULL;



static void addExt(char *ext)
{
	char **ent = NULL;
	char tmp_pat[30];
	char *p;
	int i;

	p = tmp_pat;
	*p = '*'; p++;
	*p = '.'; p++;
	for (i=0; i<strlen(ext); i++)
	{
		if (!isalnum(ext[i])) { return; } // invalid char

	
		if (isalpha(ext[i])) {
			*p = '['; p++;
			if ( p - tmp_pat >= 29) { return; }
			
			*p = toupper(ext[i]); p++;
			if ( p - tmp_pat >= 29) { return; }
			
			*p = tolower(ext[i]); p++;
			if ( p - tmp_pat >= 29) { return; }

			*p = ']'; p++;
			if ( p - tmp_pat >= 29) { return; }
		} else {
			*p = ext[i]; p++;
			if ( p - tmp_pat >= 29) { return; }
		}
	}
	*p = 0;
	if ( p - tmp_pat >= 29) { return; }

//	printf("%s\n", tmp_pat);

	if (FilePatterns) { 
		ent = FilePatterns;
		/* find the last entry */
		while (*ent)	{
			ent++;
		}
		*ent = strdup(tmp_pat);
	}
}

/* return the pointer to the PLUGIN_CONFIG struct found in the global
 * configuration structure found by the plugin's name */
static PLUGIN_CONFIG *PluginManager_getPluginConfig(const char *plugin_name)
{
	int i;
	if (config.cnt_plugin_config > 0)
	{
		for (i=0; i<config.cnt_plugin_config; i++) {
			if (strcmp(plugin_name, config.plugin_config[i]->plugin_name)==0)
			{
				return config.plugin_config[i];
			}
		}
	}
	return NULL;
}

char **PluginManager_getFilePatterns(void)
{
	return FilePatterns;
}

void PluginManager_updatePatterns(void)
{
	MikMood_InputPlugin *inp; 
	char **ent = NULL;
	int count=0;

	/* first, count how much entry we will have */
	inp = input_plugins;
	while (inp != NULL)
	{
		char **exts;
		if (inp->listFileExts) {
			exts = inp->listFileExts();
			while (*exts) {
				count ++;
				exts++;
			}
		}
		inp = (MikMood_InputPlugin*)inp->next;
	}

	FilePatterns = calloc(sizeof(char*) * (count + 1), 1);

	inp = input_plugins;
	while (inp != NULL)
	{
		char **exts;
		if (inp->listFileExts) {
			exts = inp->listFileExts();
			while (*exts) {
				addExt(*exts);
				count ++;
				exts++;
			}
		}
		inp = (MikMood_InputPlugin*)inp->next;
	}
}

int PluginManager_registerInputPlugin(MikMood_InputPlugin *inp)
{
	if (inp->init()) { return -1; }

	if (input_plugins) {
		inp->next = input_plugins;
		input_plugins = inp;
	} else {
		input_plugins = inp;
		inp->next = NULL;
	}	
	
	/* If plugin is configurable, look for a previously saved 
	 * configuration and apply it to this plugin. */
	if (inp->applyConfig)
	{
		PLUGIN_CONFIG *pcfg = PluginManager_getPluginConfig(inp->getName());
		PLUGIN_CONFIG *pcfg_new = NULL;
		if (pcfg) {
			inp->applyConfig(pcfg);
			pcfg_new = inp->getConfig();
			// replace with the new configuration
			memcpy(pcfg, pcfg_new, sizeof(PLUGIN_CONFIG));
		}
		else {
			pcfg_new = inp->getConfig();
		}
	}
	
	return 0;
}

int PluginManager_registerOutputPlugin(MikMood_OutputPlugin *outp)
{
	if (outp->init()) { return -1; }
	
	if (output_plugins) {
		outp->next = output_plugins;
		output_plugins = outp;
	} else {
		output_plugins = outp;
		outp->next = NULL;
	}	

	
	return 0;
}

void PluginManager_listPlugins(void)
{
	MikMood_InputPlugin *inp = input_plugins;
	MikMood_OutputPlugin *outp = output_plugins;
	
	printf("Output plugins:\n");
	while (outp != NULL)
	{
		printf("%12s - %s\n", outp->getName(), outp->getAbout());
		outp = (MikMood_OutputPlugin*)outp->next;
	}
	printf("\n");

	printf("Input plugins:\n");
	while (inp != NULL)
	{
		PluginManager_displayInputPluginInfo(inp);
		
		inp = (MikMood_InputPlugin*)inp->next;
	}

	printf("\n");
}

MikMood_OutputPlugin *PluginManager_getCurrentOutputPlugin(void)
{
	/* returns the last registered plugin for now... */
	return output_plugins;
}

/* walk the linked list of plugins, checking if each plugin has the required
 * function pointers to handle URLs, and ask each valid plugin if it
 * supports the URL. */
MikMood_InputPlugin *PluginManager_getInputPluginURL(char *url)
{
	MikMood_InputPlugin *inp = input_plugins;

//	printf("Searching for a url input plugin...\n");
	while (inp != NULL)
	{
		if (inp->testURL && inp->setURL) {
			if (inp->testURL(url)) {
				return inp;
			}
		}
		inp = inp->next;
	}

	return NULL;
}

/* walk the linked list of plugins, checking if each plugin has the required
 * functions pointers to handle FILE*, and ask each valid plugin if it
 * supports the file */
MikMood_InputPlugin *PluginManager_getInputPluginFP(FILE *fptr)
{
	MikMood_InputPlugin *inp = input_plugins;

//	printf("Searching for a file input plugin...\n");
	while (inp != NULL)
	{
		if (inp->testFP && inp->setFP) {
			if (inp->testFP(fptr)) {
				fseek(fptr, SEEK_SET, 0);
				return inp;
			}
			fseek(fptr, SEEK_SET, 0);
		}
		inp = inp->next;
	}

	return NULL;
}

/* walk the linked list of plugins, checking if each plugin has the required
 * functions pointers to handle filenames, and ask each valid plugin if it
 * supports the file */
MikMood_InputPlugin *PluginManager_getInputPluginFile(char *filename)
{
	MikMood_InputPlugin *inp = input_plugins;

	while (inp != NULL)
	{
		if (inp->testFile && inp->setFile) {
			if (inp->testFile(filename)) {
				return inp;
			}
		}
		inp = inp->next;
	}

	return NULL;
}


MikMood_InputPlugin *PluginManager_getInputPlugin_by_name(const char *name)
{
	MikMood_InputPlugin *inp = input_plugins;

	if (name)
	{
		while (inp != NULL)
		{
			if (strcmp(inp->getName(), name)==0) {
				return inp;
			}
			inp = inp->next;
		}
	}	

	return NULL;
}

void PluginManager_writePluginConfigs(void)
{
	MikMood_InputPlugin *inp = input_plugins;
	PLUGIN_CONFIG *pcfg;
	int first = 1;

	while (inp != NULL)
	{
		if (inp->getConfig)
		{
			if ((pcfg = inp->getConfig()))
			{
				if (first) {
					rc_write_struct("PLUGIN_CONFIG", "Configuration string used by each plugin\n");
				}
				else {
					rc_write_struct("PLUGIN_CONFIG",NULL);					
				}
				write_plugin_config(pcfg);
				
				rc_write_struct_end(NULL);
			}
		}
		inp = inp->next;
	}
	
}

void PluginManager_displayInputPluginInfo(MikMood_InputPlugin *inp)
{
	char **exts;
	int col=0, base;
		
	printf("%12s - %s\n", inp->getName(), inp->getAbout());
	printf("               ");
	base = col = 15;
	if (inp->listFileExts) {
		exts = inp->listFileExts();
		while (*exts) {
			printf(".%s ",*exts);
			
			col += strlen(*exts)+2;
			if (col>=79) { 
				printf("\n"); 
				col = base; 
				printf("               ");
			}
			
			exts++;
		}
	}
	printf("\n");
}

void PluginManager_displayPluginInfo(const char *plugin_name)
{
	MikMood_InputPlugin *inp;

	if (plugin_name)
	{
		inp = PluginManager_getInputPlugin_by_name(plugin_name);
		if (inp)
		{
			PluginManager_displayInputPluginInfo(inp);
			printf("\n");
		/*
			if (inp->getConfigParams) {
				printf("Configurable parameters:\n");
				printf("%s\n", inp->getConfigParams());
			}*/
		}
		else
		{
			printf("No plugin found by that name (%s)\n", plugin_name);			
		}
	}
}



