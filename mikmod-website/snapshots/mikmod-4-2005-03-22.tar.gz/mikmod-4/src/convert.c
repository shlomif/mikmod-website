#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "convert.h"
#include <endian.h>

//#define DBG_TRACE(...) printf(__VA_ARGS__)
#define DBG_TRACE(...)

void printfmt(AudioFMT *fmt)
{
	switch (fmt->format)
	{
		case AUDIO_FORMAT_8_S:
			printf("AUDIO_FORMAT_8_S");
			break;
		case AUDIO_FORMAT_8_U:
			printf("AUDIO_FORMAT_8_U");
			break;
		case AUDIO_FORMAT_16_S:
			printf("AUDIO_FORMAT_16_S");
			break;
		case AUDIO_FORMAT_16_LE_S:
			printf("AUDIO_FORMAT_16_LE_S");
			break;
		case AUDIO_FORMAT_16_BE_S:
			printf("AUDIO_FORMAT_16_BE_S");
			break;
		case AUDIO_FORMAT_16_U:
			printf("AUDIO_FORMAT_16_U");
			break;
		case AUDIO_FORMAT_16_LE_U:
			printf("AUDIO_FORMAT_16_LE_U");
			break;
		case AUDIO_FORMAT_16_BE_U:
			printf("AUDIO_FORMAT_16_BE_U");
			break;
	}
	
	if (fmt->stereo) { printf(" [Stereo]"); } else { printf(" [Mono]"); }
	printf("%d hz\n", fmt->sample_rate);

}


AudioConverter *AudioConverter_create(AudioFMT *src_fmt, AudioFMT *dst_fmt, int max_samples)
{
	AudioConverter *ac;
	int max_num_channels=0;
	int bufsize;

	ac = malloc(sizeof(AudioConverter));
	if (ac == NULL) { return NULL; }

	ac->src_fmt = src_fmt;
	ac->dst_fmt = dst_fmt;
	ac->result = NULL;
	ac->max_samples = max_samples;

	/* Calculate the biggest buffer we will need for the conversion. 
	 *
	 * max_num_channels * 4
	 *
	 * */
	if (FMT_NUM_CHANNELS(src_fmt) > max_num_channels) {
		max_num_channels = FMT_NUM_CHANNELS(src_fmt);		
	}
	if (FMT_NUM_CHANNELS(dst_fmt) > max_num_channels) {
		max_num_channels = FMT_NUM_CHANNELS(dst_fmt);
	}


	bufsize = 4 * max_num_channels * max_samples;
//	bufsize = 1000000;
//	printf("Using two %d bytes large buffer for conversion\n", bufsize);
//	printfmt(src_fmt);
//	printfmt(dst_fmt);

	ac->buf1 = malloc(bufsize);	
	ac->buf2 = malloc(bufsize);	
	
	return ac;
}

void AudioConverter_free(AudioConverter *cnv)
{
	if (cnv)
	{
		free(cnv->buf1);
		free(cnv->buf2);
		free(cnv);
	}
}

unsigned char *AudioConverter_do(AudioConverter *cnv, unsigned char *dat, int num_samples)
{	
	char *buf_src = cnv->buf1;
	char *buf_dst = cnv->buf2;
	char *buf_tmp;
	AudioFMT tmp_fmt;


	memcpy(&tmp_fmt, cnv->src_fmt, sizeof(AudioFMT));	
/*
	if (cnv->src_fmt->format == cnv->dst_fmt->format)
	{
		if ( (cnv->src_fmt->stereo && cnv->dst_fmt->stereo) ||
		     (!cnv->src_fmt->stereo && !cnv->dst_fmt->stereo) )
		{
			DBG_TRACE("-- convert not needed\n");	
			cnv->result = buf_src;
			return buf_src;
		}
	}
*/
	
DBG_TRACE("-- convert\n");	
	
#define SWAP_BUFS() { buf_tmp = buf_src; buf_src = buf_dst; buf_dst = buf_tmp; }

//	printfmt(cnv->src_fmt);
//	printfmt(cnv->dst_fmt);

	convert_copy(dat, buf_src, num_samples, FMT_BYTES_PER_SAMPLE_C(cnv->src_fmt));

	/* swap to native endianness */
	switch (tmp_fmt.format)
	{
		case AUDIO_FORMAT_16_LE_S:
#if __BYTE_ORDER == __BIG_ENDIAN
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_S;
			SWAP_BUFS();
#endif
#if __BYTE_ORDER == __LITTLE_ENDIAN
			/* map to native */
			tmp_fmt.format = AUDIO_FORMAT_16_S;			
#endif
			break;
		case AUDIO_FORMAT_16_LE_U:
#if __BYTE_ORDER == __BIG_ENDIAN
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_U;
			SWAP_BUFS();
#endif
#if __BYTE_ORDER == __LITTLE_ENDIAN
			/* map to native */
			tmp_fmt.format = AUDIO_FORMAT_16_U;
#ifdef DEBUG_CONVERSION	
			printfmt(&tmp_fmt);
#endif
#endif
			break;
		case AUDIO_FORMAT_16_BE_S:
#if __BYTE_ORDER == __LITTLE_ENDIAN
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_S;
			SWAP_BUFS();
#endif
#if __BYTE_ORDER == __BIG_ENDIAN
			/* map to native */
			tmp_fmt.format = AUDIO_FORMAT_16_S;			
#endif
			break;
		case AUDIO_FORMAT_16_BE_U:
#if __BYTE_ORDER == __LITTLE_ENDIAN
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_U;
			SWAP_BUFS();
#endif
#if __BYTE_ORDER == __BIG_ENDIAN
			/* map to native */
			tmp_fmt.format = AUDIO_FORMAT_16_U;			
#endif
			break;
		default:
			DBG_TRACE("8 bit sound, no need to care about endianness\n");	
	}

	/* convert unsigned to signed */
	switch (tmp_fmt.format)
	{
		case AUDIO_FORMAT_8_U:
			convert_u8_to_s8(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_8_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 8 bit unsigned to signed\n");
			break;
		case AUDIO_FORMAT_16_U:
			convert_u16_to_s16(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 16 bit unsigned to signed\n");
			break;
		default:
			DBG_TRACE("No unsigned to signed conversion needed\n");
	}

	/* raise to 32 bit samples */
	switch (tmp_fmt.format)
	{
		case AUDIO_FORMAT_8_S:
			convert_s8_to_s32(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_32_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 8 bit signed to 32 bit signed\n");
			break;
		case AUDIO_FORMAT_16_S:
			convert_s16_to_s32(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_32_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 16 bit signed to 32 bit signed\n");
			break;
		default:
			printf("What!!!\n");
	}


	if (tmp_fmt.format != AUDIO_FORMAT_32_S) {
		printf("Error!!\n");
		return NULL;
	}
	

	/* raise/lower number of chanels */
	if (FMT_NUM_CHANNELS(&tmp_fmt) != FMT_NUM_CHANNELS(cnv->dst_fmt))
	{
		switch (FMT_NUM_CHANNELS(&tmp_fmt))
		{
			case 1:
				convert_mono_s32_to_stereo_s32(buf_src, buf_dst, num_samples);
				tmp_fmt.stereo = 1;
				SWAP_BUFS();
				DBG_TRACE("Converted mono to stereo\n");
				break;
			case 2:
				convert_stereo_s32_to_mono_s32(buf_src, buf_dst, num_samples);
				tmp_fmt.stereo = 0;
				SWAP_BUFS();
				DBG_TRACE("Converted stereo to mono\n");
				break;
		}
	}
	else
	{
		DBG_TRACE("Number of channels match.\n");
	}


	/* convert from 32 bit to final sample size */
	switch (FMT_BYTES_PER_SAMPLE(cnv->dst_fmt))
	{
		case 2:			
			convert_s32_to_s16(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 32 bit signed to 16 bit signed\n");
			break;
		case 1:
			convert_s32_to_s8(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_8_S;
			SWAP_BUFS();
			DBG_TRACE("Converted 32 bit signed to 8 bit signed\n");
			break;
	}


	/* convert to unsigned if necessary */
	switch (cnv->dst_fmt->format)
	{
		case AUDIO_FORMAT_16_U:
		case AUDIO_FORMAT_16_LE_U:
		case AUDIO_FORMAT_16_BE_U:
			convert_s16_to_u16(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_16_U;
			SWAP_BUFS();
			DBG_TRACE("Converted to 16 bit unsigned\n");
			break;
		case AUDIO_FORMAT_8_U:
			convert_s8_to_u8(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			tmp_fmt.format = AUDIO_FORMAT_8_U;
			SWAP_BUFS();
			DBG_TRACE("Converted to 8 bit unsigned\n");
			break;
	}

	/* convert from native endian to dst endian */
	switch(cnv->dst_fmt->format)
	{
#if __BYTE_ORDER == __BIG_ENDIAN
		case AUDIO_FORMAT_16_LE_S:
		case AUDIO_FORMAT_16_LE_U:
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			if (tmp_fmt.format == AUDIO_FORMAT_16_U) {
				tmp_fmt.format = AUDIO_FORMAT_16_LE_U;
			} else {
				tmp_fmt.format = AUDIO_FORMAT_16_LE_S;
			}
			SWAP_BUFS();
			break;
#endif
#if __BYTE_ORDER == __LITTLE_ENDIAN
		case AUDIO_FORMAT_16_BE_S:
		case AUDIO_FORMAT_16_BE_U:
			convert_16_swap_endian(buf_src, buf_dst, num_samples * FMT_NUM_CHANNELS(&tmp_fmt));
			if (tmp_fmt.format == AUDIO_FORMAT_16_U) {
				tmp_fmt.format = AUDIO_FORMAT_16_LE_U;
			} else {
			tmp_fmt.format = AUDIO_FORMAT_16_LE_S;
			}
			SWAP_BUFS();
			break;
#endif

	}

	cnv->result = buf_src;
	return cnv->result;
}

void convert_mono16_to_stereo16(unsigned char *src, unsigned char *dst, int num_samples)
{
	int i;
	unsigned char a, b;

	for (i=0; i<num_samples; i++)
	{
		a = *src; src++;
		b = *src; src++;

		*dst = a; dst++;
		*dst = b; dst++;
		*dst = a; dst++;
		*dst = b; dst++;
	}
}

void convert_copy(unsigned char *src, unsigned char *dst, int num_samples, int bytes_per_sample)
{
	switch(bytes_per_sample)
	{
		case 1:
			return convert_copy8(src, dst, num_samples);
		case 2:
			return convert_copy16(src, dst, num_samples);
		default:
			memcpy(dst, src, num_samples*bytes_per_sample);
			return;
	}
}

void convert_copy16(unsigned char *src, unsigned char *dst, int num_samples)
{
	int i;

	for (i=0; i<num_samples; i++)
	{
		*dst = *src; src++; dst++;
		*dst = *src; src++; dst++;
	}
}

void convert_copy8(unsigned char *src, unsigned char *dst, int num_samples)
{
	memcpy(dst, src, num_samples);
}


void convert_u8_to_s8(unsigned char *src, unsigned char *dst, int num_samples)
{
	convert_s8_to_u8(src, dst, num_samples);
}

void convert_u16_to_s16(unsigned char *src, unsigned char *dst, int num_samples)
{
	convert_s16_to_u16(src, dst, num_samples);
}

void convert_s8_to_s32(unsigned char *src, unsigned char *dst, int num_samples)
{
	int *d = (int*)dst;
	char *s = (char*)src;

	do {
		*d = (*s)<<24; s++; d++;
	}
	while (--num_samples);
}

void convert_s16_to_s32(unsigned char *src, unsigned char *dst,
		int num_samples)
{
	short *s = (short*)src;
	int *d = (int*)dst;

	do {
		*d = (*s)<<16; s++; d++;
	}
	while (--num_samples);
}


void convert_s32_to_s16(unsigned char *src, unsigned char *dst, int num_samples)
{
	int *s = (int*)src;
	short *d = (short*)dst;
	
	do {
		*d = (*s)>>16; s++; d++;
	}
	while (--num_samples);
}

void convert_s32_to_s8(unsigned char *src, unsigned char *dst, int num_samples)
{
	char *d = (char*)dst;
	int *s = (int*)src;

	do {
		*d = (*s)>>24; s++; d++;
	}
	while (--num_samples);
}

void convert_s16_to_u16(unsigned char *src, unsigned char *dst, int num_samples)
{
	short *s = (short*)src;
	unsigned short *d = (unsigned short*)dst;

	do {
		*d = *s ^ 0x8000; d++; s++;
	} while(--num_samples);
}

void convert_s8_to_u8(unsigned char *src, unsigned char *dst, int num_samples)
{
	unsigned char *s = (unsigned char*)src;
	
	do {
		*dst = (*s) ^ 0x80; dst++; s++;
	} while(--num_samples);
}

void convert_16_swap_endian(unsigned char *src, unsigned char *dst, int num_samples)
{
	register unsigned char tmp;

	do {
		tmp = *src; src++;
		*dst = *src; src++; dst++;
		*dst = tmp; dst++;
	} while (--num_samples);
}

void convert_mono_s32_to_stereo_s32(unsigned char *src, unsigned char *dst, int num_samples)
{
	int *s = (int*)src;
	int *d = (int*)dst;

	do {
		*d = *s; d++;
		*d = *s; d++; s++;
	} while(--num_samples);
}

void convert_stereo_s32_to_mono_s32(unsigned char *src, unsigned char *dst, int num_samples)
{
	int *s = (int*)src;
	int *d = (int*)dst;
	int t;
	
	do {
		t = *s; s++;
		*d = ((*s)>>1) + (t>>1); d++;
	} while(--num_samples);
}


