/*  MikMod module player
	(c) 1998 - 2000 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: engine.c,v 1.13 2005/02/28 03:07:15 raph Exp $

  Threaded player functions

==============================================================================*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "engine.h"
#include "mthreads.h"
#include "mconfig.h"
#include "mutilities.h"

#include "file_info.h"
#include "plugin.h"
#include "plugin_manager.h"
#include "plugin_load.h"

//#define DEBUG_PRINTF(...) printf("%p : ", cur_inp); printf(__VA_ARGS__); fflush(stdout);
#define DEBUG_PRINTF(...)

//extern MODULE *mf;

//#if LIBMIKMOD_VERSION >= 0x030200
//static MP_DATA playdata;
//#endif
static mm_bool active = 0, paused = 1, use_threads = 0;
static int volume = -1;

static DEFINE_MUTEX(data);
static DEFINE_THREAD(updater,updater_mode);

static MikMood_InputPlugin *cur_inp = NULL;

static void do_update(void)
{
	
	
#if 0
#if LIBMIKMOD_VERSION >= 0x030200
	int i;
	unsigned long cur_time;
#endif
	mm_bool locked = 0;

	MikMod_Update();

	if (updater_mode == MTH_RUNNING) {
		MUTEX_LOCK(data);
		locked = 1;
	}
	if (volume>=0) {
		Player_SetVolume (volume);
		volume = -1;
	}

	paused = Player_Paused();
	active = Player_Active();

#if LIBMIKMOD_VERSION >= 0x030200
	if (mf) {
		if (!config.fakevolbars) {
			cur_time = Time1000();
			for (i = 0; i < mf->numchn; i++) {
				playdata.vstatus[i].time = cur_time;
				playdata.vstatus[i].volamp =
					(Voice_RealVolume(Player_GetChannelVoice(i))
					 * playdata.vinfo[i].volume) >> 16;
			}
		}
		/* Query current voice status */
		Player_QueryVoices(mf->numchn, playdata.vinfo);
	}
#endif
	if (locked)
		MUTEX_UNLOCK(data);
#endif
}
#if 0
#ifdef USE_THREADS
#ifdef HAVE_PTHREAD
static void* MP_updater(void *dummy)
#else
static void MP_updater(void *dummy)
#endif
{
	while (active && (updater_mode == MTH_RUNNING)) {
		do_update();
		SLEEP(5);
	}

	updater_mode = MTH_NORUN;
	active = 0;
	paused = 1;
#ifdef HAVE_PTHREAD
	return NULL;
#else
	return;
#endif
}
#endif
#endif
/* Initialise the threads. Returns if threads are used. */
mm_bool EN_Init (void)
{
	DEBUG_PRINTF("EN_Init\n");
	char *homedir = getenv("HOME");
	char home_plugins[255];

	if (homedir) {
		snprintf(home_plugins, 255, "%s/.mikmod/plugins/", homedir);
		load_plugins(home_plugins);
	}
	
//	PluginManager_listPlugins();

	return 0;
#if 0
#ifdef USE_THREADS
	static int firstcall = 1;

	if (firstcall) {
		firstcall = 0;
		use_threads = 1;
		if (!MikMod_InitThreads() || !INIT_MUTEX(data))
			use_threads = 0;
	}
#endif
	return use_threads;
#endif
}

void EN_Shutdown(void)
{
	DEBUG_PRINTF("EN_Shutdown\n");
}

mm_bool EN_setFP(FILE *fp)
{
	DEBUG_PRINTF("setFP\n");
	/* stop current file */
	if (cur_inp) {
		cur_inp->stop();
	}

	/* try to find an input plugin which claims to
	 * support the file */
	cur_inp = PluginManager_getInputPluginFP(fp);
	if (cur_inp) {
		/* load it or initialize... */
		cur_inp->setFP(fp);
		return 1;
	}
	return 0;
}

char *EN_getTitle(char *filename)
{
	FILE *tmpfile;
//	char *title;
	MikMood_InputPlugin *inp = NULL;
	
	tmpfile = fopen(filename, "r");
	if (tmpfile == NULL) { return NULL; }

	inp = PluginManager_getInputPluginFP(tmpfile);
	if (inp) { return "TODO"; }
	
	fclose(tmpfile);
	return NULL;
}

mm_bool EN_setURL(char *url)
{
	/* stop current file */
	if (cur_inp) {
		cur_inp->stop();
	}

	/* try to find an input plugin which claims to
	 * support the url */
	cur_inp = PluginManager_getInputPluginURL(url);
	if (cur_inp) {
		/* load it or initialize... */
		cur_inp->setURL(url);
		return 1;
	}
	return 0;

}

mm_bool EN_setFile(char *filename)
{
	if (cur_inp) {
		cur_inp->stop();
	}

//	printf("FIlename: %s\n", filename);
	
	/* try to find an input plugin which claims to
	 * support the file */
	cur_inp = PluginManager_getInputPluginFile(filename);
	if (cur_inp) {
		/* load it or initialize... */
		cur_inp->setFile(filename);
		return 1;
	}
	return 0;



}

void EN_Play (void)
{
	DEBUG_PRINTF("EN_Play\n");
	if (cur_inp)
	{
		cur_inp->play(PluginManager_getCurrentOutputPlugin());
		paused = 0;
	}
#if 0
	EN_Init();
	do_update();
#ifdef USE_THREADS
	if (use_threads) {
		updater_mode = MTH_RUNNING;
		use_threads = THREAD_START(updater, MP_updater, NULL);
	}
#endif
#endif
}

void EN_Update (void)
{
	DEBUG_PRINTF("EN_Update\n");
	if (cur_inp) { cur_inp->update(); }
#if 0
	if (!use_threads) {
		do_update();
	}
#endif
}

/* Removes the thread started by EN_Start() */
void EN_Stop (void)
{
	DEBUG_PRINTF("EN_Stop\n");
#if 0
	if (updater_mode == MTH_RUNNING)
		THREAD_JOIN(updater,updater_mode);
#endif
	if (cur_inp) { cur_inp->stop(); }
	active = 0;
	paused = 1;
}

/* Wrapper for Player_Active() */
mm_bool EN_Active (void)
{
	DEBUG_PRINTF("EN_Active\n");
	if (cur_inp) { 
		active = !cur_inp->isStopped();
		return active;
	}
	return 0;
}

/* Wrapper for Player_TogglePause() */
void EN_TogglePause (void)
{
	DEBUG_PRINTF("EN_TogglePause\n");
	if (cur_inp) { 
		cur_inp->togglePause(); 
		paused = cur_inp->isPaused();
	}
#if 0
	Player_TogglePause();
	paused = Player_Paused();
#endif
}

/* Wrapper for Player_Paused() */
mm_bool EN_Paused (void)
{
	DEBUG_PRINTF("EN_Paused\n");
	
	if (cur_inp) { return cur_inp->isPaused(); }
	return 1; // no input... equivalent to pause
}

/* Wrapper for Player_SetVolume() */
void EN_Volume (int vol)
{
}

MikMood_FileInfo *EN_getInfo(void)
{
	DEBUG_PRINTF("EN_getInfo\n");
	if (cur_inp) { return cur_inp->getFileInfo(); }
	return NULL;
}

void EN_Restart(void)
{
	if (cur_inp) {
		if (cur_inp->rew) {
			cur_inp->restart();
		}
		else
		{
			cur_inp->stop();
			cur_inp->play(PluginManager_getCurrentOutputPlugin());
		}
	}
}

void EN_ff(char big)
{
	if (cur_inp) {
		if (cur_inp->ff) {
			cur_inp->ff(big);
		}
	}
}

void EN_rew(char big)
{
	if (cur_inp) {
		if (cur_inp->rew) {
			cur_inp->rew(big);
		}
	}
}

