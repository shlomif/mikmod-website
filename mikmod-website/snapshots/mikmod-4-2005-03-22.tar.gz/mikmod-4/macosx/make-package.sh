#!/bin/sh -x

MACOSX=`uname -r | perl -n -e \
'print(($_ ge "7.0") ? "10.3" : ($_ ge "6.0") ? "10.2" : "10.1")'`

sudo rm -rf /tmp/mikmod

if [ ! -x build/mikmod -o ! -r build/mikmod.1 ]; then
	if [ "$MACOSX" = "10.3" ]; then
		xcodebuild -project mikmod.xcode
	else
		pbxbuild
	fi
fi

mkdir -p /tmp/mikmod/Root

sudo install -d -m 0755 /tmp/mikmod/Root/usr/bin
sudo install -m 0755 build/mikmod /tmp/mikmod/Root/usr/bin
sudo install -d -m 0755 /tmp/mikmod/Root/usr/share/man/man1
sudo install -m 0644 build/mikmod.1 /tmp/mikmod/Root/usr/share/man/man1

# Very important, these two steps:
sudo chown root:admin /tmp/mikmod/Root
sudo chmod 1775 /tmp/mikmod/Root

cp -pr Resources /tmp/mikmod/Resources

open MikMod.pmsp

exit 0
