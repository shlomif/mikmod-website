#ifndef _plugin_load_h__
#define _plugin_load_h__

int load_plugins(char *dir);
int load_input_plugin(char *file);
int load_output_plugin(char *file);

#endif // _plugin_load_h__

