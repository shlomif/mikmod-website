#include <stdio.h>
#include <stdlib.h>
#include "plugin.h"

static PARAM *findParam(PLUGIN_CONFIG *cfg, const char *param_name, int type)
{
	int i;
	for (i=0; i<cfg->cnt_params; i++)
	{
		if (cfg->params[i].type == type)
		{
			if (strcmp(cfg->params[i].name, param_name)==0)
			{
				return &cfg->params[i];
			}
		}
	}
}

int pluginConfig_copyParam(PLUGIN_CONFIG *dst, PLUGIN_CONFIG *src, const char *param_name)
{
	int i;
	PARAM *dst_param, *src_param;
	
	for (i=0; i<=MM_PARAM_MAX; i++)
	{
		dst_param = findParam(dst, param_name, i);
		if (!dst_param) { continue; }
		src_param = findParam(src, param_name, i);
		if (!src_param) { continue; }

		memcpy(dst_param, src_param, sizeof(PARAM));
	}
}

int pluginConfig_setInt(PLUGIN_CONFIG *cfg, const char *param_name, int val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_RANGE);
	if (!p) { return -1; }

	p->range.value = val;
}

int pluginConfig_setBool(PLUGIN_CONFIG *cfg, const char *param_name, int val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_RANGE);
	if (!p) { return -1; }

	p->boolean.value = val;
}

int pluginConfig_setString(PLUGIN_CONFIG *cfg, const char *param_name, char *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_STRING);
	if (!p) { return -1; }
	
	p->string.value = val;
}

int pluginConfig_getInt(PLUGIN_CONFIG *cfg, const char *param_name, int *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_RANGE);
	if (!p) { return -1; }

	*val = p->range.value;
}


int pluginConfig_getBool(PLUGIN_CONFIG *cfg, const char *param_name, int *val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_BOOLEAN);
	if (!p) { return -1; }
	
	*val = p->boolean.value;
}

int pluginConfig_getString(PLUGIN_CONFIG *cfg, const char *param_name, char **val)
{
	PARAM *p = findParam(cfg, param_name, MM_PARAM_STRING);
	if (!p) { return -1; }
	
	*val = p->string.value;
}

int pluginConfig_addParam(PLUGIN_CONFIG *cfg, const char *param_name, int type)
{	
	PARAM *p;
	if (cfg->cnt_params==0)
	{
		cfg->params = calloc(sizeof(PARAM), 1);
		if (cfg->params == NULL) { return -1; }
		cfg->params[0].name = param_name;
		cfg->params[0].type = type;
		cfg->cnt_params++;
	}
	else
	{
		p = (PARAM*)realloc(
				cfg->params, 
				sizeof(PARAM)*
				(cfg->cnt_params+1));
		if (p==NULL) { return -1; }
		cfg->params = p;
		memset(&cfg->params[cfg->cnt_params], 0, sizeof(PARAM));
		cfg->params[cfg->cnt_params].name = param_name;
		cfg->params[cfg->cnt_params].type = type;
		cfg->cnt_params++;
	}
	return 0;
}

PLUGIN_CONFIG *pluginConfig_create(const char *plugin_name)
{
	PLUGIN_CONFIG *cfg;

	cfg = malloc(sizeof(PLUGIN_CONFIG));
	if (!cfg) { return NULL; }
	
	cfg->plugin_name = plugin_name;
	cfg->cnt_params = 0;
	cfg->params = NULL;
	
	return cfg;
}



