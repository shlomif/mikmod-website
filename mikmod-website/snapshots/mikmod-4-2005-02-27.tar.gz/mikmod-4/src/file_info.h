#ifndef _file_info_h__
#define _file_info_h__


typedef struct {
	char *name; 
} MikMood_SampleInfo;

typedef struct {
	char *name;
} MikMood_InstrumentInfo;

#define FI_VALUE_INT	0
#define FI_VALUE_FLOAT	1
typedef struct {
	int type; 
	union {
		int int_val;
		float float_val;
	};
} MikMood_Value;

typedef struct
{
	char *title;	/* title of the song */
	char *author;	/* name of the author */
	char *type;		/* type fo file. eg ImpulseTracker 2.14p3 */
	char *comments;

	int num_samples; /* -1 if not supported, 0 if none.. */
	int num_instruments; /* -1 if not supported, 0 if none.. */
	
	/* if not null, has information about samples */
	MikMood_SampleInfo *sampleInfo;

	/* if not null, has information about instruments */
	MikMood_InstrumentInfo *instrumentInfo;

	/* if the file has a concept of bitrate/sample rate/timer */
	char *sng_rate_type; /* a string, eg "bitrate" or "samplerate" or "timer" */
	char *sng_rate_unit; /* the unit, eg "hz" or "khz" or "bps" */
//	int sng_rate; // the current rate (or constant rate)
	MikMood_Value sng_rate;

	/* The total time of the song in seconds and the current position in seconds. 
	 *
	 * You should update current_time by counting the samples you output.
	 * 
	 * If the total time is infinite/unknown, set total_time to 0 and dont touch 
	 * it anymore as the player will fill it itself once the file as completely played. */
	int current_time;
	int total_time;
	
	/* progression indicators for the song (the current osong if many
	 * songs are supported in the same file).
	 *
	 * if no progress/subprogress type is supported, leave the strings NULL
	 */
	char *sng_progress_type; /* a string, eg "orders" or "bytes" or "frames" of seconds... */
	int sng_progress; /* the progression in the unit explained above. cannot be negative */
	int sng_progress_max; /* the maximum value of sng_progress, -1 if infinite */

	char *sng_subprogress_type; /* a string, eg like "position" in the cuurent 'order' (see above) */
	int sng_subprogress;
	int sng_subprogress_max;

	int num_channels; /* 0 if this concept is not applicable to the file */
	int num_channels_in_use; /* The number of channels in use NOW */
} MikMood_FileInfo;

#ifdef __cplusplus
extern "C" {
#endif

MikMood_FileInfo *FI_create(int num_samples, int num_instruments);
void FI_free(MikMood_FileInfo *fi);
void FI_dump(MikMood_FileInfo *fi);
void FI_getStatusLine(MikMood_FileInfo *fi, char *buf, int buf_size);
void FI_dumpStatus(MikMood_FileInfo *fi);

#ifdef __cplusplus
}
#endif

#endif // _file_info_h__


