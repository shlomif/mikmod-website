#ifndef _plugin_manager_h__
#define _plugin_manager_h__

#include <stdio.h>

#include "plugin.h"

#ifdef __cplusplus
extern "C" {
#endif

int PluginManager_registerInputPlugin(MikMood_InputPlugin *inp);
int PluginManager_registerOutputPlugin(MikMood_OutputPlugin *outp);

void PluginManager_listPlugins(void);
void PluginManager_displayInputPluginInfo(MikMood_InputPlugin *inp);
void PluginManager_displayPluginInfo(const char *plugin_name);

char **PluginManager_getFilePatterns(void);

MikMood_OutputPlugin *PluginManager_getCurrentOutputPlugin(void);
MikMood_InputPlugin *PluginManager_getInputPluginURL(char *url);
MikMood_InputPlugin *PluginManager_getInputPluginFP(FILE *fp);
MikMood_InputPlugin *PluginManager_getInputPluginFile(char *filename);

MikMood_InputPlugin *PluginManager_getInputPlugin_by_name(const char *name);

#ifdef __cplusplus
}
#endif

#endif // _plugin_manager_h__

