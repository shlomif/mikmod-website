#ifndef _input_plugin_h__
#define _input_plugin_h__

#include <stdio.h>
#include "file_info.h"
#include "audio_fmt.h"

/* helpers for plugins */
#define DECLARE_TIME_COUNTER(name) static int name = 0;
#define ADD_SAMPLES_TO_COUNTER(name, num_samples, afmt) do { name += num_samples; } while(0);
#define GET_SECONDS_FROM_COUNTER(name, afmt) ( (name) / ((afmt)->sample_rate))
#define REMOVE_SECONDS_FROM_COUNTER(name, afmt) do { name -= GET_SECONDS_FROM_COUNTER(name, afmt) * (afmt)->sample_rate; } while(0);

#define MM_PARAM_RANGE	0
#define MM_PARAM_BOOLEAN	1
#define MM_PARAM_STRING	2
#define MM_PARAM_MAX 2
typedef struct {
	int min, max, value;
} PARAM_RANGE;

typedef struct {
	int value;
} PARAM_BOOLEAN;

typedef struct {
	char *value;
} PARAM_STRING;

typedef union {
	const char *name;
	int type;
	union {
		PARAM_RANGE 	range;
		PARAM_BOOLEAN 	boolean;
		PARAM_STRING	string;
	};
} PARAM;

typedef struct {
	const char *plugin_name;
	int cnt_params;
	PARAM *params;
} PLUGIN_CONFIG;

int pluginConfig_getInt(PLUGIN_CONFIG *cfg, const char *param_name, int *val);
int pluginConfig_getBool(PLUGIN_CONFIG *cfg, const char *param_name, int *val);
int pluginConfig_getString(PLUGIN_CONFIG *cfg, const char *param_name, char **val);
int pluginConfig_setInt(PLUGIN_CONFIG *cfg, const char *param_name, int val);
int pluginConfig_setBool(PLUGIN_CONFIG *cfg, const char *param_name, int val);
int pluginConfig_setString(PLUGIN_CONFIG *cfg, const char *param_name, char *val);

/* find and copy a param if it exist in both configs */
int pluginConfig_copyParam(PLUGIN_CONFIG *dst, PLUGIN_CONFIG *src, const char *param_name);

int pluginConfig_addParam(PLUGIN_CONFIG *cfg, const char *param_name, int type);

PLUGIN_CONFIG *pluginConfig_create(const char *plugin_name);


typedef struct {
	char *(*getName)(void);
	char *(*getAbout)(void);

	int (*init)(void);
	
	int (*openAudio)(AudioFMT *fmt);
	void (*closeAudio)(void);
	
	void (*writeAudio)(void *data, int num_samples);
	void (*flush)(void);
	void (*pause)(int paused);
	int (*getFree)(void); /* returns number of samples that
	can be written */

	/* filled by MikMood */
	void *next;
	void *dlhandle;
} MikMood_OutputPlugin;



typedef struct 
{
	char *(*getName)(void);
	char *(*getAbout)(void);
	
	int (*init)(void);
	void (*shutdown)(void);
	
	/* OPTIONAL: return an array containing strings for supported file
		extensions. eg: s3m, mod, ogg... Used to know which file are of 
		interest in archives. Array is terminated by a NULL ptr. */
	char **(*listFileExts)(void);

	int (*testURL)(char *url); /* return true if supported */
	int (*testFP)(FILE *fp); /* return true if supported */

	/* fallback in case implementing plugin with FILE* is too tricky */
	int (*testFile)(char *filename); 

	/* set the file that will be played. If necessary, load it now */
	int (*setURL)(char *url);
	int (*setFP)(FILE *fp); 
	/* fallback in case implementing plugin with FILE* is too tricky */
	int (*setFile)(char *filename);
	
	/* play the file/url previously set. The plugin must keep
	 * a copy of the output plugin passed here until it
	 * is stopped. */
	int (*play)(MikMood_OutputPlugin *out);

	void (*stop)(void);
	int (*isStopped)(void);
	
	void (*togglePause)(void);
	int (*isPaused)(void);

	/* give cpu time to plugin */
	void (*update)(void);

	/* get a pointer to the input plugin current file info. This 
	can be called each time the display is updated, so be careful
	no to take too much time */
	MikMood_FileInfo *(*getFileInfo)(void);

	/* seeking functionalities */
	void (*restart)(void);

	/* skip forward or reverse. if big is true, skip using
	   a bigger step. How bigger is the step is up to the
	   plugin to decide. */
	void (*ff)(char big);
	void (*rew)(char big);

	/* get/set for configuration */
	PLUGIN_CONFIG *(*getConfig)(void);
	void (*applyConfig)(PLUGIN_CONFIG *cfg);

	/* filled by MikMood */	
	void *next;
	void *dlhandle;
//	void *config_str; // copy of pointer in mconfig.h
} MikMood_InputPlugin;

#endif // _input_plugin_h__

