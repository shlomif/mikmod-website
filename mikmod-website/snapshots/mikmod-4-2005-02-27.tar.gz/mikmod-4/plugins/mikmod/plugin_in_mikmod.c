#include <stdio.h>
#include <mikmod.h>

#include "plugin.h"
#include "plugin_manager.h"
#include "plugin_in_mikmod.h"

#define BUFFER_SIZE 44100

static unsigned char *buf=NULL;
static MODULE *mod=NULL;
static int playing = 0;
static AudioFMT fmt;
static MikMood_FileInfo *fi=NULL;
static MikMood_OutputPlugin *g_outp=NULL;

static int plugin_in_init(void);

static char *fileexts[] = { "669", "amf", "apun", "dsm", "far", "gdm", "it", "imf", "mod", "med", "mtm", "okt", "s3m", "stm", "stx", "ult", "uni", "xm", NULL };


static void plugin_in_shutdown(void)
{
	if (buf != NULL) { free(buf); }

	if (playing) {
		Player_Stop();
	}

	if (mod != NULL) {
		Player_Free(mod);
	}	

	MikMod_Exit();
}

static int plugin_in_testFP(FILE *fp)
{
	char *title = Player_LoadTitleFP(fp);
	if (title!=NULL) { 
		free(title); return 1; 
	}

	return 0;
}

static int plugin_in_setFP(FILE *fp)
{
	int i;
	int n_instruments=-1;

	if (fi) { FI_free(fi); fi = NULL; }
	if (mod) { Player_Free(mod); mod = NULL; }

	mod = Player_LoadFP(fp, 255, 0);
	if (mod == NULL) { 
		fprintf(stderr, "Could not laod module, reason: %s\n",
				MikMod_strerror(MikMod_errno));
		return -1; 
	}

	/* if instruments are not supported, mod->instruments is NULL and 
	 * the value of mod->numins is equal to mod->numsmp */
	if (mod->instruments) {
		n_instruments = mod->numins;
	}

	fi = FI_create(mod->numsmp, n_instruments);
	if (fi == NULL) {
		fprintf(stderr, "Failed to alloc file info structure\n");
		Player_Free(mod);
		return -1;
	}

	fi->title = mod->songname;
	fi->author = NULL;
	fi->type = mod->modtype;
	fi->comments = mod->comment;

	fi->num_samples = mod->numsmp;
	for (i=0; i<fi->num_samples; i++) {
		if (mod->samples[i].samplename) {
			fi->sampleInfo[i].name = mod->samples[i].samplename;
		} else {
			fi->sampleInfo[i].name = "";
		}
	}

	if (mod->instruments) {
		fi->num_instruments = mod->numins;
		for (i=0; i<mod->numins; i++) {
			if (mod->instruments[i].insname) {
				fi->instrumentInfo[i].name = mod->instruments[i].insname;
			} else {
				fi->instrumentInfo[i].name = "";
			}
		}
	} 
	else {
	//	printf("No instruments\n");
		fi->num_instruments = -1;
	}

	fi->sng_progress_type = "pat";
	fi->sng_progress = 0;
	fi->sng_progress_max = mod->numpat-1;

	
	fi->sng_subprogress_type = "pos";
	fi->sng_subprogress_max = -1;
	fi->sng_subprogress = 0;

	fi->num_channels = mod->numchn;
	fi->num_channels_in_use = 0;

	return 0;
}

static int plugin_in_play(MikMood_OutputPlugin *out)
{
	g_outp = out;
	Player_Start(mod);
	return 0;
}

static void plugin_in_stop(void)
{
	Player_Stop();	
	g_outp = NULL;
}

static int plugin_in_isStopped(void)
{
	return !Player_Active();	
}

static void plugin_in_togglePause(void)
{
	Player_TogglePause();
}

static int plugin_in_isPaused(void)
{
	return Player_Paused();	
}

static void plugin_in_update(void)
{
	/* just call mikmod update, which will
		eventually call our driver update func */
	if (!Player_Active()) { 
		playing = 0;
	}
	MikMod_Update();
	fi->num_channels_in_use = mod->realchn;
	fi->sng_subprogress = mod->patpos;
	fi->sng_progress = mod->sngpos;
}

static char *plugin_in_getName(void) { return "libmikmod"; }
static char *plugin_in_getAbout(void) { return "module player using libmikmod"; }

static char **plugin_in_listFileExts(void)
{
	return fileexts;
}


static MikMood_FileInfo *plugin_in_getFileInfo(void)
{
	return fi;
}

static void plugin_in_ff(char big)
{
	Player_NextPosition();
}

static void plugin_in_rew(char big)
{
	Player_PrevPosition();
}

static void plugin_in_restart(void)
{
	Player_SetPosition(0);
}

static BOOL mikmood_IsThere(void)
{
	//printf("--------- Mikmood_IsThere\n");
	return 1;
}

static BOOL mikmood_PlayStart(void)
{
	//printf("--------- Mikmood_PlayStart\n");
	
	if (g_outp == NULL) { return 1; }

	/* use the mode libmikmod wants to use */
	if (md_mode & DMODE_16BITS) {
		fmt.format = AUDIO_FORMAT_16_S;
	} else {
		fmt.format = AUDIO_FORMAT_8_U;
	}
	
	fmt.sample_rate = md_mixfreq;

	if (md_mode & DMODE_STEREO) {
		fmt.stereo = 1;
	} else {
		fmt.stereo = 0;
	}
	
	g_outp->openAudio(&fmt);
	playing = 1;

	return VC_PlayStart();
}

static void mikmood_PlayStop(void)
{
	//printf("--------- Mikmood_PlayStop\n");
	
	if (g_outp == NULL) { return; }
	
	if (playing) {
		g_outp->closeAudio();
	}

	VC_PlayStop();
}

static BOOL mikmood_Reset(void)
{
	return 0;
}

static void mikmood_Update(void)
{
	int must_do, done;

	if (g_outp == NULL) { return; }

	/* get number of samples we can write */
	must_do = g_outp->getFree();
	
	/* WARNING: 16 bit stereo assumed */
	if (must_do*FMT_BYTES_PER_SAMPLE_C(&fmt) > BUFFER_SIZE) {
		must_do = BUFFER_SIZE/FMT_BYTES_PER_SAMPLE_C(&fmt);
	}

	done = VC_WriteBytes(buf, must_do * FMT_BYTES_PER_SAMPLE_C(&fmt));
	done /= FMT_BYTES_PER_SAMPLE_C(&fmt);

	g_outp->writeAudio(buf, done);
}

MDRIVER drv_mikmood = {
	NULL, /* next */
	"mikmood",	/* name */
	"mikmood output driver v0.1", /* version */
	0,	/* hard voice limit */
	255,/* soft voice limit */
	"mikmood", /* alias */
#if (LIBMIKMOD_VERSION >= 0x030200)
	NULL, /* cmdline help */
#endif
	NULL, /* cmdline */
	mikmood_IsThere,
	VC_SampleLoad,
	VC_SampleUnload,
	VC_SampleSpace,
	VC_SampleLength,
	VC_Init, /*mikmood_Init,*/
	VC_Exit, /* mikmood_Exit, */
	mikmood_Reset,
	VC_SetNumVoices,
	mikmood_PlayStart, /*VC_PlayStart,*/
	mikmood_PlayStop, /*VC_PlayStop,*/
	mikmood_Update,
	NULL,				/* pause */
	VC_VoiceSetVolume,
	VC_VoiceGetVolume,
	VC_VoiceSetFrequency,
	VC_VoiceGetFrequency,
	VC_VoiceSetPanning,
	VC_VoiceGetPanning,
	VC_VoicePlay,
	VC_VoiceStop,
	VC_VoiceStopped,
	VC_VoiceGetPosition,
	VC_VoiceRealVolume
};


static int plugin_in_init(void)
{
	buf = malloc(BUFFER_SIZE);
	if (buf == NULL) { return -1; }

	//printf("Initialising mikmod\n");
	MikMod_RegisterDriver(&drv_mikmood);	

	MikMod_RegisterAllLoaders();
	
//	MikMod_RegisterAllDrivers();
	
	md_mode |= DMODE_SOFT_MUSIC;
	//md_mode &= ~(DMODE_16BITS);

	if (MikMod_Init(NULL)) { 
		printf("mikmod init failed, %s\n", MikMod_strerror(MikMod_errno));
		return -1; 
	}

	return 0;
}


static MikMood_InputPlugin plugin_in_mikmod = {
	plugin_in_getName,
	plugin_in_getAbout,
	plugin_in_init,
	plugin_in_shutdown,
	plugin_in_listFileExts,
	NULL, // testURL
	plugin_in_testFP,
	NULL, // testFile
	NULL, // setURL
	plugin_in_setFP,
	NULL, // setFile
	plugin_in_play,
	plugin_in_stop,
	plugin_in_isStopped,
	plugin_in_togglePause,
	plugin_in_isPaused,
	plugin_in_update,
	plugin_in_getFileInfo,
	plugin_in_restart,
	plugin_in_ff,
	plugin_in_rew,
	NULL, // getConfig
	NULL, // applyConfig
	
	NULL, // next
	NULL // dlhandle
};

MikMood_InputPlugin *getInputPlugin(void) { return &plugin_in_mikmod; }


