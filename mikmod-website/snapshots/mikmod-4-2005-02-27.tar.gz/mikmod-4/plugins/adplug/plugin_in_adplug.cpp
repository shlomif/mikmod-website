/*
 * Input plugin for adlib music formats, using adplug
 * 
 * Written by Raphael Assenat, greatly inspired from adplug-xmms
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "plugin.h"
#include "plugin_manager.h"
#include "file_info.h"

#include <adplug/adplug.h>
#include <adplug/emuopl.h>
//#include <adplug/slientopl.h>
#include <adplug/silentopl.h>
#include <adplug/players.h>

extern "C" {
	int plugin_in_init();
	void plugin_in_shutdown();
	int plugin_in_testFile(char *);
	int plugin_in_setFile(char *);
	int plugin_in_play(void);
	void plugin_in_update(void);
	void plugin_in_stop(void);
	int plugin_in_isStopped(void);
	void plugin_in_togglePause(void);
	int plugin_in_isPaused(void);
	char *plugin_in_getName(void);
	char *plugin_in_getAbout(void);
	char **plugin_in_listFileExts(void);
	MikMood_FileInfo *plugin_in_getFileInfo(void);
	MikMood_InputPlugin *getInputPlugin(void);
};

static char *fileexts[] = { "A2M", "AMD", "BAM", "CFF", "CMF", "D00", "DFM", "DMO", "DRO", "DTM", "HSC", "HSP", "IMF", "KSM", "LAA", "LDS", "M", "MAD", "MID", "MKJ", "MTK", "RAD", "RAW", "ROL", "S3M", "SA2", "SAT", "SCI", "SNG", "XAD", "XMS", "XSM", NULL };

static int playing = 0;
static int paused = 0;

#define BUFFER_SIZE 44100
static unsigned char buffer[BUFFER_SIZE];

static MikMood_FileInfo *fi=NULL;
static MikMood_OutputPlugin *g_outp = NULL;
static AudioFMT g_fmt;

static CEmuopl *g_opl = NULL;
static CPlayer *g_player = NULL;



int plugin_in_init()
{
	playing = 0;
	paused = 0;

	return 0;
}

void plugin_in_shutdown()
{
}

int plugin_in_testFile(char *filename)
{
	CSilentopl tmpopl;
	CPlayer *p = CAdPlug::factory(filename,&tmpopl);

	if (p) { delete p; return 1; }
	
	return 0;
}

int plugin_in_setFile(char *filename)
{
	unsigned int i;
	
	playing = 0;
	paused = 0;
	
	g_fmt.format = AUDIO_FORMAT_16_S;
	g_fmt.stereo = 0;
	g_fmt.sample_rate = 44100;

	if (g_player) { delete g_player; g_player = NULL; }
	if (g_opl) { delete g_opl; g_opl = NULL; }
	if (fi) { FI_free(fi); }

	g_opl = new CEmuopl(g_fmt.sample_rate, 1, g_fmt.stereo);
	if (!g_opl) { return -1; }


	g_player = CAdPlug::factory(filename,g_opl);
	if (!g_player) { return -1; }
	
	fi = FI_create(-1, g_player->getinstruments());

	fi->title = (char*)g_player->gettitle().data();
	fi->author = (char*)g_player->getauthor().data();
	fi->type = (char*)g_player->gettype().data();
	fi->comments = (char*)g_player->getdesc().data();
	
	fi->sng_progress_type = "order";
	fi->sng_progress_max = g_player->getorders();

	fi->sng_subprogress_type = "row";

	fi->sng_rate_type = "timer";
	fi->sng_rate_unit = "hz";
	fi->sng_rate.type = FI_VALUE_FLOAT;
	fi->sng_rate.float_val = 0.0;
	
	if (g_player->getinstruments())
	{
		for (i=0; i<g_player->getinstruments(); i++)
		{
			fi->instrumentInfo[i].name = (char*)g_player->getinstrument(i).data();
		}
	}

	return 0;
}

int plugin_in_play(MikMood_OutputPlugin *outp)
{
	g_outp = outp;
	if (g_outp == NULL) { return 0; }

	g_outp->openAudio(&g_fmt);
	
	playing = 1;
	paused = 0;

	return 0;
}

#define MIN(a, b) ( ((a) < (b)) ? (a) : (b))

void plugin_in_update(void)
{
	int samples_to_do;
	long i, towrite;
	unsigned char *buffer_pos;
	static long toadd = 0;

	if (playing && !paused)
	{
		samples_to_do = g_outp->getFree();	
		if (samples_to_do * FMT_BYTES_PER_SAMPLE_C(&g_fmt) > BUFFER_SIZE) {
			samples_to_do = BUFFER_SIZE / FMT_BYTES_PER_SAMPLE_C(&g_fmt);
		}

		towrite = samples_to_do; buffer_pos = buffer;
		while (towrite > 0)
		{
			while (toadd < 0) 
			{
				toadd += g_fmt.sample_rate;
				playing = g_player->update();
			}
			i = MIN(towrite, (long)(toadd / g_player->getrefresh() + 4) & ~3);
			g_opl->update((short*)buffer_pos, i);
			buffer_pos += i * FMT_BYTES_PER_SAMPLE_C(&g_fmt); towrite -= i;
			toadd -= (long)(g_player->getrefresh() * i);
		}
		fi->sng_rate.float_val = g_player->getrefresh();

		g_outp->writeAudio(buffer, samples_to_do);
	}
}

void plugin_in_stop(void)
{
	if (g_outp) {
		g_outp->closeAudio();
		g_outp = NULL;
	}
	playing = 0;
}

int plugin_in_isStopped(void)
{
	return !playing;
}

void plugin_in_togglePause(void)
{
	paused = !(paused);
}

int plugin_in_isPaused(void)
{
	return paused;
}

char *plugin_in_getName(void) { return "adplug"; }
char *plugin_in_getAbout(void) { return  "Adlib music input plugin using adplug"; }
char **plugin_in_listFileExts(void) { return fileexts; }

MikMood_FileInfo *plugin_in_getFileInfo(void)
{	
	fi->sng_progress = g_player->getorder();
	fi->sng_subprogress = g_player->getrow();
	

	return fi;
}

static MikMood_InputPlugin plugin_in_adplug = {
	plugin_in_getName,
	plugin_in_getAbout,
	plugin_in_init,
	plugin_in_shutdown,
	plugin_in_listFileExts,
	NULL, // testURL	
	NULL, // testFP
	plugin_in_testFile,
	NULL, // setURL
	NULL, // setFP
	plugin_in_setFile,
	plugin_in_play,
	plugin_in_stop,
	plugin_in_isStopped,
	plugin_in_togglePause,
	plugin_in_isPaused,
	plugin_in_update,
	plugin_in_getFileInfo,
	NULL, // restart
	NULL, // ff
	NULL, // rew
	NULL, // getConfig
	NULL, // applyConfig,

	NULL, // next
	NULL  // dlhandle


};



MikMood_InputPlugin *getInputPlugin(void) { return &plugin_in_adplug; }

