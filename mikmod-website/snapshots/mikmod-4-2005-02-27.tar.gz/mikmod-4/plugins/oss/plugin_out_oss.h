#ifndef _plugin_out_oss_h__
#define _plugin_out_oss_h__

int Plugin_out_oss_register();

#endif // _plugin_out_oss_h__

