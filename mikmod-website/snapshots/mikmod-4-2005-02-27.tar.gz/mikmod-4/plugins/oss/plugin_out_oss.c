#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <endian.h>

#include <sys/soundcard.h>
#include <sys/ioctl.h>

#include "plugin.h"
#include "plugin_manager.h"
#include "plugin_out_oss.h"
#include "convert.h"

static int fd=-1;
static AudioFMT real_fmt;
static AudioFMT requested_fmt;

static AudioConverter *ac = NULL;


#define MAX_SAMPLES	44100

#define DBG_PRINTF(...)


static unsigned char oss2format(int afmt)
{
	switch(afmt)
	{
		case AFMT_S8: return AUDIO_FORMAT_8_S;
		case AFMT_U8: return AUDIO_FORMAT_8_U;
		case AFMT_S16_LE: return AUDIO_FORMAT_16_LE_S;
		case AFMT_S16_BE: return AUDIO_FORMAT_16_BE_S;
		case AFMT_U16_LE: return AUDIO_FORMAT_16_LE_U;
		case AFMT_U16_BE: return AUDIO_FORMAT_16_BE_U;
	}
	
	return 0;
}

static int format2oss(unsigned char format)
{
	unsigned int afmt;

	switch (format)
	{
		case AUDIO_FORMAT_8_S:
			afmt = AFMT_S8;
			break;
		case AUDIO_FORMAT_8_U:
			afmt = AFMT_U8;
			break;
		case AUDIO_FORMAT_16_S:
			/* endian dependant */
#if __BYTE_ORDER == __LITTLE_ENDIAN
			afmt = AFMT_S16_LE;
#else
			afmt = AFMT_S16_BE;
#endif
			break;
		case AUDIO_FORMAT_16_LE_S:
			afmt = AFMT_S16_LE;
			break;
		case AUDIO_FORMAT_16_BE_S:
			afmt = AFMT_S16_BE;
			break;
		case AUDIO_FORMAT_16_U:
#if __BYTE_ORDER == __LITTLE_ENDIAN
			afmt = AFMT_U16_LE;
#else
			afmt = AFMT_U16_BE;
#endif
			break;
		case AUDIO_FORMAT_16_LE_U:
			afmt = AFMT_U16_LE;
			break;
		case AUDIO_FORMAT_16_BE_U:
			afmt = AFMT_U16_BE;
			break;
	}
	return afmt;
}


int plugin_out_init(void)
{
	return 0;
}

int plugin_out_openAudio(AudioFMT *fmt)
{
	unsigned int afmt;
	int tmp;

	real_fmt.format = fmt->format;
	real_fmt.sample_rate = fmt->sample_rate;
	real_fmt.stereo = fmt->stereo;
	
	requested_fmt.format = fmt->format;
	requested_fmt.sample_rate = fmt->sample_rate;
	requested_fmt.stereo = fmt->stereo;
	
	DBG_PRINTF("Oss init\n");

	fd = open("/dev/dsp", O_WRONLY);
	if (fd<0) {
		return -1;
	}

	if (ioctl(fd, SNDCTL_DSP_RESET)) {
		perror("SNDCTL_DSP_RESET");
		close(fd);
		fd = -1;
		return -1;
	}

	/* set channels (mono/stereo) */
#ifdef SNDCTL_DSP_CHANNELS
	tmp = real_fmt.stereo?2:1;
	DBG_PRINTF("Requesting %d channels\n", tmp);
	if (ioctl(fd, SNDCTL_DSP_CHANNELS, &tmp)) {
		perror("SNDCTL_DSP_CHANNELS");
		close(fd);
		fd = -1;
		return -1;
	}
	if (tmp==2) { 
		real_fmt.stereo = 1; 
	} else if (tmp==1) {
		real_fmt.stereo = 0;
	} else {
		DBG_PRINTF("Requested %d channels, but got %d channels!\n",  requested_fmt.stereo?2:1 ,tmp);
		close(fd);
		fd = -1;
		return -1;
	}
	
#else
	if (ioctl(fd, SNDCTL_DSP_STEREO, &real_fmt.stereo)) {
		perror("SNDCTL_DSP_STEREO");
		close(fd);
		fd = -1;
		return -1;
	}
#endif

	/* set audio format */
	afmt = format2oss(real_fmt.format);
	requested_fmt.format = oss2format(afmt); /* convert endian independant format id to dependent one */
	if (ioctl(fd, SNDCTL_DSP_SETFMT, &afmt)) {
		perror("SNDCTL_DSP_SETFMT");
		close(fd);
		return -1;
	}
	real_fmt.format = oss2format(afmt);

	/* set sample rate */
	if (ioctl(fd, SNDCTL_DSP_SPEED, &real_fmt.sample_rate)) {
		perror("SNDCTL_DSP_SPEED");
		close(fd);
		fd = -1;
		return -1;
	}


	
	/* compare what we requested with what we got */
	DBG_PRINTF("Requested %d channels, got %d channels\n", requested_fmt.stereo?2:1, real_fmt.stereo?2:1);		
	DBG_PRINTF("Requested a sample rate of %d, got %d\n", requested_fmt.sample_rate, real_fmt.sample_rate);
	DBG_PRINTF("Requested a format %d, got %d\n", requested_fmt.format, real_fmt.format);

	ac = AudioConverter_create(&requested_fmt, &real_fmt, MAX_SAMPLES);
	if (ac == NULL) {
		close(fd);
		fd = -1;
		return -1;
	}

	return 0;
}

void plugin_out_closeAudio(void)
{
	if (fd >= 0) {
		close(fd);
		fd = -1;
	}

	if (ac != NULL) { AudioConverter_free(ac); ac = NULL; }
}

void plugin_out_writeAudio(void *data, int len)
{
	unsigned char *res;

	res = AudioConverter_do(ac, data, len);
	write(fd, res, len * FMT_BYTES_PER_SAMPLE_C(&real_fmt));
}

void plugin_out_flush(void)
{
	ioctl(fd, SNDCTL_DSP_SYNC, 0);
}

void plugin_out_pause(int paused)
{
}

int plugin_out_getFree(void)
{
	//return 882; /* gives 50hz updates at 44100 khz sample rate */
	return 4410;
}

char *plugin_out_getName(void) { return "oss"; }
char *plugin_out_getAbout(void) { return "Simple OSS output plugin"; }

