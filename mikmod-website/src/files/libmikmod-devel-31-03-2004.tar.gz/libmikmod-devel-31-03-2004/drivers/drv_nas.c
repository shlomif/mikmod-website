/*	MikMod sound library
	(c) 2003, 2004 Raphael Assenat    
	(c) 1998, 1999, 2000 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_nas.c,v 1.11 2004/03/31 01:03:58 raph Exp $

  Driver for NAS output, written by Raphael Assenat <raph@raphnet.net>

==============================================================================*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/* audiolib has a define for the type BOOL,
 * so I use this trick to create a separate type
 * name for libmikmod's BOOLs.
 *
 * Maybe all libmikmod types should be prefixed by MK_ ??
 * */ 
#define BOOL MK_BOOL
#include "mikmod_internals.h"
#undef BOOL 

#ifdef DRV_NAS

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <stdio.h>

#include <audio/audiolib.h>

static CHAR *server_string=NULL;
static AuServer *auserv;
static AuDeviceID device=AuNone;
static AuFlowID flow;
static AuElement elements[3];

#define DEFAULT_FRAGSIZE 4096
static ULONG fragsize=DEFAULT_FRAGSIZE;
static SBYTE *audio_buffer;

static void send_bytes(int num_bytes)
{
	int b;
	
	while (num_bytes)
	{
		if (num_bytes>fragsize) {
			b = fragsize;
		} else {
			b = num_bytes;
		}

		VC_WriteBytes(audio_buffer, b);
		AuWriteElement(auserv, flow, 0, b, audio_buffer, AuFalse, NULL);
		num_bytes -= b;
	}	
	AuSync(auserv, AuFalse);
}

static AuBool eventHandler(AuServer *aud, AuEvent *ev, AuEventHandlerRec *handler)
{
	int xf;
	
	switch(ev->type)
	{
		case AuEventTypeElementNotify:
		{
			AuElementNotifyEvent *event = (AuElementNotifyEvent*)ev;
			
			switch (event->kind)
			{
				case AuElementNotifyKindLowWater:
					/* send more bytes (event->num_bytes) */
					xf = event->num_bytes;
					//printf("Low water, request for %d bytes\n", event->num_bytes);
					send_bytes(xf);
					
					break;
				case AuElementNotifyKindState:
				{
					switch(event->cur_state)
					{
						case AuStatePause:
							if (event->reason != AuReasonUser)
							{
								/* sendmore bytes (event->num_bytes) */
								xf = event->num_bytes;
								send_bytes(xf);
							}
							break;
					}
				}
			}
		}
		break;
	}
	
	return AuTrue;
}

static UBYTE needed_tracks(void)
{
	return (md_mode & DMODE_STEREO) ? 2 : 1;
}

static ULONG data_format(void)
{
	unsigned int little_endian=1;
	
	if (md_mode & DMODE_16BITS) {
		if (!(*(char*)&little_endian)) {
			return AuFormatLinearSigned16MSB; 
		} else {
			return AuFormatLinearSigned16LSB; 
		}
	} else {
		return AuFormatLinearUnsigned8;
	}
}

/* open the server 
 * return true if successfull */
static MK_BOOL openServer(void)
{
	auserv = AuOpenServer(server_string, 0, NULL, 0, NULL, NULL);
	if (!auserv) {
		return 0;
	}

	return 1;
}

static void closeServer(void)
{
	if (auserv) {
		AuCloseServer(auserv);
	}
}

static void NAS_CommandLine(CHAR *cmdline)
{
	CHAR *ptr;
	
	if((ptr=MD_GetAtom("server",cmdline,0))) {
		server_string=ptr;
		if (server_string) {
			_mm_free(server_string);
		}
		server_string=ptr;
	}

	if((ptr=MD_GetAtom("fragsize",cmdline,0))) {
		fragsize=atoi(ptr);

		if((fragsize<1024)||(fragsize>32768)) fragsize=DEFAULT_FRAGSIZE;
		_mm_free(ptr);
	}
}

static MK_BOOL NAS_IsThere(void)
{
	return 1;
	printf("NAS IsThere\n");
	MK_BOOL ok;
	ok = openServer();
	if (ok) {
		closeServer();
	}
	return ok;

}

static MK_BOOL NAS_Init(void)
{
//	printf("NAS Init\n");
	
	audio_buffer = _mm_malloc(fragsize);
	if (audio_buffer==NULL) { return 1; }

//	openServer();
	
	return VC_Init();
}

static void NAS_Exit(void)
{
	printf("NAS Exit\n");
	VC_Exit();
	AuStopFlow(auserv, flow, NULL);	
	closeServer();
	_mm_free(audio_buffer);
}

static void NAS_Update(void)
{
	AuHandleEvents(auserv);
}

static MK_BOOL NAS_PlayStart(void)
{
	int i;

//	printf("NAS PlayStart\n");
	openServer();
	
	/* Look for a suitable output device */
	for (i=0; i < AuServerNumDevices(auserv); i++)
	{
		/* we need a physical output device */
		if (AuDeviceKind(AuServerDevice(auserv, i)) == 
				AuComponentKindPhysicalOutput)
		{
			/* with the correct number of tracks */
			if (AuDeviceNumTracks(AuServerDevice(auserv, i)) == needed_tracks())
			{
				/* and the right rate. Adjust the mixing rate 
				 * if it is out of bounds */	
				if (md_mixfreq > AuDeviceMaxSampleRate(AuServerDevice(auserv, i))) {
					md_mixfreq = AuDeviceMaxSampleRate(AuServerDevice(auserv, i));
				} 
				else if (md_mixfreq < AuDeviceMinSampleRate(AuServerDevice(auserv, i))) {
					md_mixfreq = AuDeviceMinSampleRate(AuServerDevice(auserv, i));
				}

				device = AuDeviceIdentifier(AuServerDevice(auserv, i));
				break;	
			}			
		}
	}
	if (device == AuNone) { return 1; }

	
	flow = AuCreateFlow(auserv, NULL);
	if (!flow) { return 1; }
	
	AuMakeElementImportClient(&elements[0], md_mixfreq, data_format(), needed_tracks(),
									AuTrue, fragsize, fragsize/4*2, 0, NULL);
	AuMakeElementExportDevice(&elements[1], 0, device, md_mixfreq, AuUnlimitedSamples, 0, NULL);
	AuSetElements(auserv, flow, AuTrue, 2, elements, NULL);
	
	AuRegisterEventHandler(auserv, AuEventHandlerIDMask, 0, flow, eventHandler, NULL);

	AuStartFlow(auserv, flow, NULL);
	
	return VC_PlayStart();
}


static void NAS_PlayStop(void)
{
	printf("NAS_PlayStop\n");

	VC_PlayStop();
	closeServer();	
}

static MK_BOOL NAS_Reset(void)
{
	NAS_Exit();
	return NAS_Init();
}

MIKMODAPI MDRIVER drv_nas={
	NULL,
	"Network Audio System (NAS)",
	"Network Audio System driver (NAS) v0.1",
	0,255,
	"nas",
	"server:t::Server\n"
    "fragsize:r:1024,32768,4096:Fragment size\n",
	NAS_CommandLine,
	NAS_IsThere,
	VC_SampleLoad,
	VC_SampleUnload,
	VC_SampleSpace,
	VC_SampleLength,
	NAS_Init,
	NAS_Exit,
	NAS_Reset,
	VC_SetNumVoices,
	NAS_PlayStart,
	NAS_PlayStop,
	NAS_Update,
	NULL,
	VC_VoiceSetVolume,
	VC_VoiceGetVolume,
	VC_VoiceSetFrequency,
	VC_VoiceGetFrequency,
	VC_VoiceSetPanning,
	VC_VoiceGetPanning,
	VC_VoicePlay,
	VC_VoiceStop,
	VC_VoiceStopped,
	VC_VoiceGetPosition,
	VC_VoiceRealVolume
};

#else

MISSING(drv_nas);

#endif // ifdef DRV_NAS

/* ex:set ts=4: */
