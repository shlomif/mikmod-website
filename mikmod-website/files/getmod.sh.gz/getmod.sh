#!/bin/bash
# getmod.sh version 1.2
#
# This script is called by random_play.sh
#
DOWNLOAD_URL=http://www.modarchive.com/cgi/random.cgi
DIR_TMP=tmp		# if you change this, change it also in random_play.sh

while true; do
	echo -en "Downloading new file\n"

	wget $DOWNLOAD_URL -P $DIR_TMP;
	while [ $? != 0 ]; do
		echo "RETRY..."
		wget $DOWNLOAD_URL -P $DIR_TMP;
	done

	while [ ! -f "play" ]; do
		sleep 1
	done
	rm play
done;


