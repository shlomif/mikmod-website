/*  MikMod example player
	(c) 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
 
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
    02111-1307, USA.
*/

/*==============================================================================

  $Id: mutilities.h,v 1.4 1999/07/11 17:49:33 miod Exp $

  Some utility functions

==============================================================================*/

#ifndef MUTILITIES_H
#define MUTILITIES_H

/* allocate memory for a formated string and do a sprintf */
char *str_sprintf2(char*,char*,char*);
char *str_sprintf(char*,char*);

/* allocate and return a name for a temporary file */
char *get_tmp_name(void);

BOOL file_exist(char*);
/* determines if a given path is absolute or relative */
BOOL path_relative(char*);

/* allocate and return a filename including the path for a config file
   'name': filename without the path */
char* get_cfg_name(char*);

#endif /* MUTILITIES_H */
