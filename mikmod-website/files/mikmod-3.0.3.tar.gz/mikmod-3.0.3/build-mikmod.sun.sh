#!/bin/sh
cd playercode
make -f makefile.sun
cd ..
cd mmio
make -f makefile.sun
cd ..
cd usercode
make -f makefile.sun
cp mikmod ../..
cd ../..
strip mikmod
echo All done.
