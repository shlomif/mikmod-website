#!/bin/sh
cd playercode
gmake -f makefile.freebsd
cd ..
cd mmio
gmake -f makefile.freebsd
cd ..
cd usercode
gmake -f makefile.freebsd
cp mikmod ../..
cd ../..
strip mikmod
echo All done.
