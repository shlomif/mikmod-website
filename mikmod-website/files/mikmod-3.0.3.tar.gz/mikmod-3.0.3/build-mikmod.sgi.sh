#!/bin/sh
cd playercode
make -f makefile.sgi
cd ..
cd mmio
make -f makefile.sgi
cd ..
cd usercode
make -f makefile.sgi
cp mikmod ../
cd ../
strip mikmod
echo All done.
