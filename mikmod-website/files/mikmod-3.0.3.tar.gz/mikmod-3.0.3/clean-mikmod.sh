#!/bin/sh
rm -f mikmod
cd playercode
make clean
cd ..
cd mmio
make clean
cd ..
cd usercode
make clean
echo All clean.
