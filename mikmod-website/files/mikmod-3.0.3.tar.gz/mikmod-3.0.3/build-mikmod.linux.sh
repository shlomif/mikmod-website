#!/bin/sh
cd playercode
make -f makefile.linux
cd ..
cd mmio
make -f makefile.linux
cd ..
cd usercode
make -f makefile.linux
cp mikmod ../
cd ../
strip mikmod
echo All done.
