#ifndef _attr_h__
#define _attr_h__

void attr_init_colors(int quiet);
void attr_banner(void);
void attr_banner1(void);
void attr_version(void);
void attr_normal(void);
void attr_song_name1(void);
void attr_song_name2(void);
void attr_file1(void);
void attr_file2(void);
void attr_file3(void);
void attr_driver1(void);
void attr_driver2(void);
void attr_type1(void);
void attr_type2(void);
void attr_type3(void);
void attr_type4(void);
void attr_type5(void);
void attr_info1(void);
void attr_info2(void);
void attr_info3(void);
void attr_info4(void);
void attr_sample_num(void);
void attr_sample_name(void);
void attr_inst_num(void);
void attr_inst_name(void);
void attr_list_num(void);
void attr_list_sort(void);
void attr_list_name(void);
void attr_list_time(void);
void attr_list_pack(void);
void attr_bottom_status_line1(void);


#endif // _attr_h__

