#ifdef HAVE_NCURSES_H
	#include <ncurses.h>
#else
	#include <curses.h>
#endif

#include <mikmod.h>
#include "display.h"
#include "player.h"



static int color_supported = 0;
#define MAY_DO_COLOR (color_supported && config.color)

void attr_init_colors(int quiet)
{
	if (!quiet)
	{		
		color_supported = has_colors();
		if (color_supported)
		{
			start_color();
			init_pair(1, COLOR_RED, COLOR_BLACK);
			init_pair(2, COLOR_GREEN, COLOR_BLACK);
			init_pair(3, COLOR_YELLOW, COLOR_BLACK);
			init_pair(4, COLOR_BLUE, COLOR_BLACK);
			init_pair(5, COLOR_MAGENTA, COLOR_BLACK);
			init_pair(6, COLOR_CYAN, COLOR_BLACK);
			init_pair(7, COLOR_WHITE, COLOR_BLACK);
			init_pair(8, COLOR_BLACK, COLOR_BLACK);			
			init_pair(9, COLOR_BLACK, COLOR_CYAN); // version
		}
	}
}

void attr_banner(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD|COLOR_PAIR(6));
}

void attr_banner1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

void attr_version(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(9));
}

void attr_normal(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_NORMAL);
}

/* Name: <song name>
   ^^^^^
    Use for this
*/
void attr_song_name1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* Name: song name
         ^^^^^^^^^
           Use for this
*/
void attr_song_name2(void)
{	
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD|COLOR_PAIR(2));
}

/* File: filename <(archive)>
 * ^^^^^
 *   Use for this
 */
void attr_file1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* File: filename <(archive)>
 *       ^^^^^
 *         Use for this
 */
void attr_file2(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD|COLOR_PAIR(5));
}

/* File: filename <(archive)>
 *                ^^^^^
 *       Use for this
 */
void attr_file3(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD|COLOR_PAIR(1));
}

/* Driver: 'drivername', %d bit 'surround/normal/interpolated', %d hz, 'reverb/no/value'
 *  ^^^^^^
 *   use for this
 */
void attr_driver1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* Driver: 'drivername', %d bit 'surround/normal/interpolated', %d hz, 'reverb/no/value'
 *         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *           use for this
 */
void attr_driver2(void)
{
	if (!MAY_DO_COLOR) return;
	//attrset(A_BOLD|COLOR_PAIR(4));
	//attrset(COLOR_PAIR(4));
	attrset(A_BOLD);
}

/* Type: 'module type', Periods: 'period type', 'linear/log'
 * ^^^^^
 *       Use for this
 */
void attr_type1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* Type: 'module type', Periods: 'period type', 'linear/log'
 *       ^^^^^^^^^^^^^
 *       Use for this
 */
void attr_type2(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* Type: 'module type', Periods: 'period type', 'linear/log'
 *                      ^^^^^^^^
 *                 Use for this
 */
void attr_type3(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* Type: 'module type', Periods: 'period type', 'linear/log'
 *                               ^^^^^^^^^^^^^^
 *                          Use for this
 */
void attr_type4(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* Type: 'module type', Periods: 'period type', 'linear/log'
 *                                              ^^^^^^^^^^^^^^
 *                                      Use for this
 */
void attr_type5(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 * ^^^^
 *   Use for this
 * */
void attr_status_line1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *     ^^^^^^^^^
 *        Use for this
 * */
void attr_status_line2(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *               ^^^^
 *             Use for this
 * */
void attr_status_line3(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                   ^^^^^^
 *                 Use for this
 * */
void attr_status_line4(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                          ^^^^
 *                       Use for this
 * */
void attr_status_line5(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                              ^^^^^^^
 *                         Use for this
 * */
void attr_status_line6(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                      ^^^^
 *                                  Use for this
 * */
void attr_status_line7(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                          ^^^^^^^^^^^
 *                                          Use for this
 * */
void attr_status_line8(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                                      ^^^^^
 *                                                   Use for this
 * */
void attr_status_line9(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                                           ^^^^^^^^^^^^^^^^^^^^^
 *                                                               Use for this
 * */
void attr_status_line10(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                                                                 ^^^^
 *                                                                        Use for this
 * */
void attr_status_line11(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
}

/* pat:%03d/%03d pos:%02.2X spd:%2d/%3d vol:%3d%%/%3d%% time:%2d:%02d/<total time> chn:%d/%d
 *                                                                                     ^^^^^
 *                                                                            Use for this
 * */
void attr_status_line12(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* [ panel title ] -- H:[help] S:[samples] C:[config] 
 * ^^^^^^^^^^^^^^
 *   Use for this
 * */
void attr_info1(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(9));
}

/* [ %d Modules ] -- H:[help] S:[samples] C:[config] 
 *                ^^
 *           Use for this
 * */
void attr_info2(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* [ %d Modules ] -- H:[help] S:[samples] C:[config] 
 *                   ^^       ^^          ^^
 *              Use for this
 * */
void attr_info3(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(A_BOLD);
}

/* [ %d Modules ] -- H:[help] S:[samples] C:[config] 
 *                     ^^^^^^   ^^^^^^^^^   ^^^^^^^^
 *              Use for this
 * */
void attr_info4(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(9));
}

void attr_sample_num(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
	
}

void attr_sample_name(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(7));
}

void attr_inst_num(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(6));
	
}

void attr_inst_name(void)
{
	if (!MAY_DO_COLOR) return;
	attrset(COLOR_PAIR(7));
}


void attr_list_num(void)
{
	if (!MAY_DO_COLOR) return;
	attron(COLOR_PAIR(6));
}

void attr_list_sort(void)
{
	if (!MAY_DO_COLOR) return;
	attron(A_BOLD|COLOR_PAIR(7));
}

void attr_list_name(void)
{
	if (!MAY_DO_COLOR) return;
	attron(COLOR_PAIR(7));
}

void attr_list_time(void)
{
	if (!MAY_DO_COLOR) return;
	attron(A_BOLD|COLOR_PAIR(2));
}

void attr_list_pack(void)
{
	if (!MAY_DO_COLOR) return;
	attron(A_BOLD|COLOR_PAIR(1));
}

/* The status line  */
void attr_bottom_status_line1(void)
{
	if (!MAY_DO_COLOR) return;
	attron(A_BOLD|COLOR_PAIR(8));	
}

