/* ========== Package information */

/* Package name (MikMod) */
#undef PACKAGE
/* Package version */
#undef VERSION

/* ========== Build environment information */

/* Define if your system lacks usleep(3) */
#undef NEED_USLEEP
/* Define if your system is AIX 3.* - might be needed for 4.* too */
#undef AIX
/* Define if your system has random(3) and srandom(3) */
#undef HAVE_SRANDOM
/* Define if your system has snprintf(3) */
#undef HAVE_SNPRINTF
/* Define if your system defines random(3) and srandom(3) in math.h instead
   of stdlib.h */
#undef SRANDOM_IN_MATH_H
/* Define if your copy of <sched.h> has a _P instead of __P (old Linux libc5) */
#undef BROKEN_SCHED
/* Define if your libncurses defines resizeterm (not found in <4.2, and can be
   disabled with configure --disable-ext-functions) */
#undef HAVE_NCURSES_RESIZETERM
/* Define if TIOCGWINSZ is defined in <sys/ioctl.h> */
#undef GWINSZ_IN_SYS_IOCTL
