/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: mixer_core.h,v 1.1.1.1 2004/01/16 02:14:00 raph Exp $

  Sample mixing routines (core part)

==============================================================================*/

#ifndef _MIXER_CORE_H_
#define _MIXER_CORE_H_

#define MIX_INT        0x70
#define MIX_IDEAL      MIX_INT
#define MIX_QUADRATIC  0x20
#define MIX_LINEAR     0x10
#define MIX_POOR       0x00
#define MIX_CLICK      0x08
#define MIX_HIRES      0x04
#define MIX_SURROUND   0x02
#define MIX_STEREO     0x01
#define MIX_MASK       (MIX_INT | MIX_CLICK | MIX_HIRES | MIX_SURROUND | MIX_STEREO)

#endif
