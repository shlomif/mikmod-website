/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: mixer_core.c,v 1.1.1.1 2004/01/16 02:14:00 raph Exp $

  Sample mixing routines (core part)

==============================================================================*/

#ifndef _FUNCTION

#include "mixer_core.h"

#define _FUNCTION

#define SWORDBITS 16
#ifdef NATIVE_64BIT_INT
#define NATIVEBITS 64
#else
#define NATIVEBITS 32
#endif

/*
	The following recursions define each and every required variation of the
	mixer routine. Such complex macro abuse allows us to add, remove, and
	modify function variations at will without risk of forgetting to modify
	all of the same parts of the same type of function.
*/

#define MIX_NAME mix_00
#define MIX_MODE 0x00
#include "mixer_core.c"

#define MIX_NAME mix_01
#define MIX_MODE 0x01
#include "mixer_core.c"

#define MIX_NAME mix_03
#define MIX_MODE 0x03
#include "mixer_core.c"

#define MIX_NAME mix_04
#define MIX_MODE 0x04
#include "mixer_core.c"

#define MIX_NAME mix_05
#define MIX_MODE 0x05
#include "mixer_core.c"

#define MIX_NAME mix_07
#define MIX_MODE 0x07
#include "mixer_core.c"

#define MIX_NAME mix_08
#define MIX_MODE 0x08
#include "mixer_core.c"

#define MIX_NAME mix_09
#define MIX_MODE 0x09
#include "mixer_core.c"

#define MIX_NAME mix_0B
#define MIX_MODE 0x0b
#include "mixer_core.c"

#define MIX_NAME mix_0C
#define MIX_MODE 0x0c
#include "mixer_core.c"

#define MIX_NAME mix_0D
#define MIX_MODE 0x0d
#include "mixer_core.c"

#define MIX_NAME mix_0F
#define MIX_MODE 0x0f
#include "mixer_core.c"

#define MIX_NAME mix_10
#define MIX_MODE 0x10
#include "mixer_core.c"

#define MIX_NAME mix_11
#define MIX_MODE 0x11
#include "mixer_core.c"

#define MIX_NAME mix_13
#define MIX_MODE 0x13
#include "mixer_core.c"

#define MIX_NAME mix_14
#define MIX_MODE 0x14
#include "mixer_core.c"

#define MIX_NAME mix_15
#define MIX_MODE 0x15
#include "mixer_core.c"

#define MIX_NAME mix_17
#define MIX_MODE 0x17
#include "mixer_core.c"

#define MIX_NAME mix_18
#define MIX_MODE 0x18
#include "mixer_core.c"

#define MIX_NAME mix_19
#define MIX_MODE 0x19
#include "mixer_core.c"

#define MIX_NAME mix_1B
#define MIX_MODE 0x1b
#include "mixer_core.c"

#define MIX_NAME mix_1C
#define MIX_MODE 0x1c
#include "mixer_core.c"

#define MIX_NAME mix_1D
#define MIX_MODE 0x1d
#include "mixer_core.c"

#define MIX_NAME mix_1F
#define MIX_MODE 0x1f
#include "mixer_core.c"

#undef SWORDBITS
#undef SLONGBITS
#undef SLONGLONGBITS
#undef NATIVEBITS

#undef _FUNCTION

/* *INDENT-OFF* */
static SWORD *(*mixertable[]) (SLONG *, SWORD *, SLONG, int, SLONG, int,
							   SLONG *) =
{
/*	............lores............   ............hires............ */
/*	mono    stereo  <oops>  surr.   mono    stereo  <oops>  surr. */
	/* 00: poor mixers */
	mix_00, mix_01, mix_00, mix_03, mix_04, mix_05, mix_04, mix_07,
	/* poor mixers with de-clicking */
	mix_08, mix_09, mix_08, mix_0B, mix_0C, mix_0D, mix_0C, mix_0F,
	/* 10: linear interpolated mixers */
	mix_10, mix_11, mix_10, mix_13, mix_14, mix_15, mix_14, mix_17,
	/* ... with de-clicking */
	mix_18, mix_19, mix_18, mix_1B, mix_1C, mix_1D, mix_1C, mix_1F,
	/* 20: quadratic interpolated mixers (not ready yet) */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* ... with de-clicking */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 30: undefined */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 40: undefined */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 50: undefined */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 60: undefined */
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 70: best mixers */
	mix_10, mix_11, mix_10, mix_13, mix_14, mix_15, mix_14, mix_17,
	/* ... with de-clicking */
	mix_18, mix_19, mix_18, mix_1B, mix_1C, mix_1D, mix_1C, mix_1F
};
/* *INDENT-ON* */

#else /* _FUNCTION */

/* This is where the action begins. */

#if MIX_MODE & MIX_HIRES
#define FRACBITS FRACBITS_HQ
#define FRACMASK FRACMASK_HQ
#define CLICKBITS CLICK_SHIFT_HQ
#else
#define FRACBITS FRACBITS_LQ
#define FRACMASK FRACMASK_LQ
#define CLICKBITS CLICK_SHIFT_LQ
#endif

/* what datatype can hold an SWORD shifted by FRACBITS with some spare room? */
#if (FRACBITS + SWORDBITS + 2) <= NATIVEBITS
#define INTERPTYPE NATIVE
#else
#define INTERPTYPE SLONGLONG
#endif

#if MIX_MODE & MIX_SURROUND
#define SU(x, y)	(x)
#else
#define SU(x, y)	(y)
#endif

#if MIX_MODE & MIX_STEREO
#define ST(x)	x;
#else
#if MIX_MODE & MIX_SURROUND
#error "mixing surround mono doesn't work"
#endif
#define ST(x)
#endif

#if (MIX_MODE & MIX_INT) == MIX_LINEAR

#define FETCH() \
	(samptr[0] + \
	 (SLONG)( ((INTERPTYPE)samptr[1] - samptr[0]) * fraction >> FRACBITS))

#elif (MIX_MODE & MIX_INT) == MIX_POOR

#define FETCH() \
	(samptr[0])

#else
#error "undefined sample interpolation mode"
#endif /* MIX_MODE */

#define INCR() \
	fraction += fracinc, \
	samptr += (wholeinc + (fraction >> FRACBITS)), \
	fraction &= FRACMASK

/* *INDENT-OFF* */
static SWORD *MIX_NAME(SLONG *dest, SWORD *samptr, SLONG fraction,
					   int wholeinc, SLONG fracinc, int todo, SLONG *frac_wb)
{
	SLONG sample, sampleL = 0;
	ST(SLONG sampleR = 0)

	int volL = vnf->lvolsel;
	ST(int volR = SU(-vnf->lvolsel, vnf->rvolsel))

#if MIX_MODE & MIX_CLICK
	int click = vnf->click, ramp = vnf->rampvol;

	SLONG clickL = vnf->lastvalL * click;
	ST(SLONG clickR = vnf->lastvalR * click)

	SLONG clickdecL = vnf->lastvalL;
	ST(SLONG clickdecR = vnf->lastvalR)

	int volincL = vnf->lvolsel - vnf->oldlvol;
	ST(int volincR =
	   SU(vnf->oldlvol - vnf->lvolsel, vnf->rvolsel - vnf->oldrvol))

    volL = (volL << CLICKBITS) - volincL * ramp;
	ST(volR = (volR << CLICKBITS) - volincR * ramp)

	/* while everything needs doing */
	while (todo && click && ramp) {
		sample = FETCH();
		sampleL = (sample * volL + clickL) >> CLICKBITS;
		ST(sampleR = (sample * volR + clickR) >> CLICKBITS)

		clickL -= clickdecL;
		ST(clickR -= clickdecR)

		volL += volincL;
		ST(volR += volincR)

		*dest++ += sampleL;
		ST(*dest++ += sampleR)

		INCR();
		click--;
		ramp--;
		todo--;
	}

	/* if click expires but ramp doesn't */
	while (todo && ramp) {
		sample = FETCH();
		sampleL = sample * volL >> CLICKBITS;
		ST(sampleR = sample * volR >> CLICKBITS)

		volL += volincL;
		ST(volR += volincR)

		* dest++ += sampleL;
		ST(*dest++ += sampleR)

		INCR();
		ramp--;
		todo--;
	}

	/* if ramp expires but click doesn't */
	while (todo && click) {
		sample = FETCH();
		sampleL = (sample * volL + clickL) >> CLICKBITS;
		ST(sampleR = (sample * volR + clickR) >> CLICKBITS)

		clickL -= clickdecL;
		ST(clickR -= clickdecR)

		*dest++ += sampleL;
		ST(*dest++ += sampleR)

		INCR();
		click--;
		todo--;
	}

	vnf->rampvol = ramp;
	vnf->click = click;
	volL >>= CLICKBITS;
	ST(volR >>= CLICKBITS)
#endif /* MIX_CLICK */

	while (todo) {
		sample = FETCH();
		sampleL = sample * volL;
		ST(sampleR = sample * volR)

		*dest++ += sampleL;
		ST(*dest++ += sampleR)

		INCR();
		todo--;
	}

	vnf->lastvalL = sampleL;
	ST(vnf->lastvalR = sampleR)

	*frac_wb = fraction;
	return samptr;
}
/* *INDENT-OFF* */

#undef FRACBITS
#undef FRACMASK
#undef CLICKBITS
#undef INTERPTYPE
#undef SU
#undef ST
#undef FETCH_VARS
#undef FETCH
#undef INCR
#undef MIX_MODE
#undef MIX_NAME

#endif /* _FUNCTION */
