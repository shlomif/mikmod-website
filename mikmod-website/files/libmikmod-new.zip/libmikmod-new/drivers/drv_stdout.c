/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_stdout.c,v 1.1.1.1 2004/01/16 02:13:36 raph Exp $

  Output data to stdout

==============================================================================*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <stdlib.h>

#include "mikmod_internals.h"

#define BUFFERSIZE 32768

static SBYTE *audiobuffer = NULL;

static BOOL stdout_IsThere(void)
{
	/* only allow this driver on pipes */
	return 1 - isatty(1);
}

static BOOL stdout_Init(void)
{
	if (!(audiobuffer = (SBYTE *)_mm_malloc(BUFFERSIZE)))
		return 1;
#ifdef __EMX__
	_fsetmode(stdout, "b");
#endif
	return Mixer_Init();
}

static void stdout_Exit(void)
{
	Mixer_Exit();
#ifdef __EMX__
	_fsetmode(stdout, "t");
#endif
	_mm_free(audiobuffer);
}

static void stdout_Update(void)
{
#ifdef WIN32
	_write
#else
	write
#endif
	  (1, audiobuffer, Mixer_WriteBytes((SBYTE *)audiobuffer, BUFFERSIZE));
}

static BOOL stdout_Reset(void)
{
	Mixer_Exit();
	return Mixer_Init();
}

MDRIVER drv_stdout = {
	NULL,
	"stdout",
	"Standard output driver v1.1",
	256,
	"stdout",
	NULL,

	NULL,
	stdout_IsThere,
	Mixer_SampleLoad,
	Mixer_SampleUnload,
	Mixer_SampleSpace,
	Mixer_SampleLength,
	stdout_Init,
	stdout_Exit,
	stdout_Reset,
	Mixer_SetNumVoices,
	Mixer_PlayStart,
	Mixer_PlayStop,
	stdout_Update,
	NULL,
	Mixer_VoiceSetVolume,
	Mixer_VoiceGetVolume,
	Mixer_VoiceSetFrequency,
	Mixer_VoiceGetFrequency,
	Mixer_VoiceSetPanning,
	Mixer_VoiceGetPanning,
	Mixer_VoicePlay,
	Mixer_VoiceStop,
	Mixer_VoiceStopped,
	Mixer_VoiceGetPosition,
	Mixer_VoiceRealVolume
};

/* ex:set ts=4: */
