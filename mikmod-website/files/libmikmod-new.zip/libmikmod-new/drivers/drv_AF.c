/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_AF.c,v 1.1.1.1 2004/01/16 02:13:38 raph Exp $

  Driver for output on AF audio server.

==============================================================================*/

/*

	Written by Roine Gustafsson <e93_rog@e.kth.se>
  
	Portability:
	Unixes running Digital AudioFile library, available from
	ftp://crl.dec.com/pub/DEC/AF

	Usage:
	Run the audio server (Aaxp&, Amsb&, whatever)
	Set environment variable AUDIOFILE to something like 'mymachine:0'.
	Remember, stereo is default! See commandline switches.

	I have a version which uses 2 computers for stereo.
	Contact me if you want it.
  
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <stdlib.h>

#include <AF/AFlib.h>

#include "mikmod_internals.h"

/* Global variables */

static SBYTE *audiobuffer = NULL;
static int AFFragmentSize;
static AFAudioConn *AFaud = NULL;
static ATime AFtime;
static AC AFac;
static CHAR *soundbox = NULL;

static void AF_CommandLine(CHAR *cmdline)
{
	CHAR *machine = Driver_GetAtom("machine", cmdline, 0);

	if (machine) {
		_mm_free(soundbox);
		soundbox = machine;
	}
}

static BOOL AF_IsThere(void)
{
	if ((AFaud = AFOpenAudioConn(soundbox))) {
		AFCloseAudioConn(AFaud);
		AFaud = NULL;
		return 1;
	} else
		return 0;
}

static BOOL AF_Init(void)
{
	unsigned long mask;
	AFSetACAttributes attributes;
	int srate;
	ADevice device;
	int n;

	if (!(AFaud = AFOpenAudioConn(soundbox))) {
		_mm_errno = MMERR_OPENING_AUDIO;
		return 1;
	}

	/* Search for a suitable device */
	device = -1;
	for (n = 0; n < AFaud->ndevices; n++) {
		AFDeviceDescriptor *AFdesc = AAudioDeviceDescriptor(AFaud, n);

		if ((AFdesc->playNchannels == 2) && (md_mode & DMODE_STEREO)) {
			device = n;
			break;
		}
		if ((AFdesc->playNchannels == 1) && !(md_mode & DMODE_STEREO)) {
			device = n;
			break;
		}
	}
	if (device == -1) {
		_mm_errno = MMERR_AF_AUDIO_PORT;
		return 1;
	}

	attributes.preempt = Mix;
	attributes.start_timeout = 0;
	attributes.end_silence = 0;
	/* in case of an 8bit device, the AF converts the 16 bit data to 8 bit */
	attributes.type = LIN16;
	attributes.channels = (md_mode & DMODE_STEREO) ? Stereo : Mono;

	mask =
	  ACPreemption | ACEncodingType | ACStartTimeout | ACEndSilence |
	  ACChannels;
	AFac = AFCreateAC(AFaud, device, mask, &attributes);
	srate = AFac->device->playSampleFreq;

	md_mode |= DMODE_16BITS;	/* This driver only handles 16bits */
	AFFragmentSize = (srate / 40) * 8;	/* Update 5 times/sec */
	md_mixfreq = srate;			/* set mixing freq */

	if (md_mode & DMODE_STEREO) {
		if (!(audiobuffer = (SBYTE *)_mm_malloc(2 * 2 * AFFragmentSize)))
			return 1;
	} else {
		if (!(audiobuffer = (SBYTE *)_mm_malloc(2 * AFFragmentSize)))
			return 1;
	}

	return Mixer_Init();
}

static BOOL AF_PlayStart(void)
{
	AFtime = AFGetTime(AFac);
	return Mixer_PlayStart();
}

static void AF_Exit(void)
{
	Mixer_Exit();
	_mm_free(audiobuffer);
	if (AFaud) {
		AFCloseAudioConn(AFaud);
		AFaud = NULL;
	}
}

static void AF_Update(void)
{
	ULONG done;

	done = Mixer_WriteBytes(audiobuffer, AFFragmentSize);
	AFPlaySamples(AFac, AFtime, done, (unsigned char *)audiobuffer);
	if (md_mode & DMODE_STEREO)
		AFtime += done / 4;
	else
		AFtime += done / 2;
	/* while (AFGetTime(AFac)<AFtime-1000); */
}

MDRIVER drv_AF = {
	NULL,
	"AF driver",
	"AudioFile driver v1.3",
	256,
	"audiofile",
	"machine:t::Audio server machine (hostname:port)\n",

	AF_CommandLine,
	AF_IsThere,
	Mixer_SampleLoad,
	Mixer_SampleUnload,
	Mixer_SampleSpace,
	Mixer_SampleLength,
	AF_Init,
	AF_Exit,
	NULL,
	Mixer_SetNumVoices,
	AF_PlayStart,
	Mixer_PlayStop,
	AF_Update,
	NULL,
	Mixer_VoiceSetVolume,
	Mixer_VoiceGetVolume,
	Mixer_VoiceSetFrequency,
	Mixer_VoiceGetFrequency,
	Mixer_VoiceSetPanning,
	Mixer_VoiceGetPanning,
	Mixer_VoicePlay,
	Mixer_VoiceStop,
	Mixer_VoiceStopped,
	Mixer_VoiceGetPosition,
	Mixer_VoiceRealVolume
};

/* ex:set ts=4: */
