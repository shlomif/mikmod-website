/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_mac.c,v 1.1.1.1 2004/01/16 02:13:41 raph Exp $

  Driver for output to the Macintosh Sound Manager

==============================================================================*/

/*
	Written by Anders F Bjoerklund <afb@algonet.se>

	Based on free MADlibrary code by Antoine Rosset <RossetAntoine@bluewin.ch>
	(author of PlayerPRO)
*/


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "mikmod_internals.h"

#ifndef __SOUND__
#include <Sound.h>
#endif

#ifndef __GESTALT__
#include <Gestalt.h>
#endif

#define BUFFERSIZE 12
#define FRAGMENTS 2

static ULONG buffersize = 1 << BUFFERSIZE;
static SndChannelPtr soundChannel = NULL;	/* pointer to a sound channel */
static SndDoubleBufferHeader doubleHeader;	/* pointer to double buffers  */

static pascal void MyDoubleBackProc(SndChannelPtr soundChannel,
									SndDoubleBufferPtr doubleBuffer)
{
#pragma unused(soundChannel)
	SBYTE *buffer;
	long written;
#if TARGET_CPU_68K
	long oldA5 = SetA5(doubleBuffer->dbUserInfo[0]);
#endif

	buffer = (SBYTE *)doubleBuffer->dbSoundData;

	MUTEX_LOCK(vars);
	if (Player_Paused_internal())
		written = Mixer_SilenceBytes(buffer, buffersize);
	else
		written = Mixer_WriteBytes(buffer, buffersize);
	MUTEX_UNLOCK(vars);

	if (doubleHeader.dbhNumChannels == 2)
		written >>= 1;
	if (doubleHeader.dbhSampleSize == 16)
		written >>= 1;

	doubleBuffer->dbNumFrames = written;
	doubleBuffer->dbFlags |= dbBufferReady;

#if TARGET_CPU_68K
	SetA5(oldA5);
#endif
}

static void MAC_CommandLine(CHAR *cmdline)
{
	char *buffer = Driver_GetAtom("buffer", cmdline, 0);

	if (buffer) {
		int buf = atoi(buffer);
		
		if (buf >= 10 && buf <= 16)
			buffersize = 1 << buf;

		free(buffer);
	}
}

static BOOL MAC_IsThere(void)
{
	NumVersion nVers;

	/* need SoundManager 2.0+ for SndPlayDoubleBuffer */
	nVers = SndSoundManagerVersion();
	if (nVers.majorRev >= 2)
		return 1;
	else
		return 0;
}

static BOOL MAC_Init(void)
{
	OSErr iErr;
	int i;
	long rate, maxrate, maxbits;
	long gestaltAnswer;
	NumVersion nVers;
	Boolean Stereo, StereoMixing, Audio16;
	Boolean NewSoundManager, NewSoundManager31;

	NewSoundManager31 = NewSoundManager = false;

	nVers = SndSoundManagerVersion();
	if (nVers.majorRev >= 3) {
		NewSoundManager = true;
		if (nVers.minorAndBugRev >= 0x10)
			NewSoundManager31 = true;
	} else if (nVers.majorRev < 2) {
		/* failure, need SoundManager 2.0+ for SndPlayDoubleBuffer */
		_mm_errno = MMERR_OPENING_AUDIO;
		return 1;
	}

	iErr = Gestalt(gestaltSoundAttr, &gestaltAnswer);
	if (iErr == noErr) {
		Stereo = (gestaltAnswer & (1 << gestaltStereoCapability)) != 0;
		StereoMixing = (gestaltAnswer & (1 << gestaltStereoMixing)) != 0;
		Audio16 = (gestaltAnswer & (1 << gestalt16BitSoundIO)) != 0;
	} else
		/* failure, couldn't get any sound info at all ? */
		Stereo = StereoMixing = Audio16 = false;

#if !GENERATING68K || !GENERATINGCFM
	if (NewSoundManager31) {
		iErr = GetSoundOutputInfo(0L, siSampleRate, (void *)&maxrate);
		if (iErr == noErr)
			iErr = GetSoundOutputInfo(0L, siSampleSize, (void *)&maxbits);
	}

	if (iErr != noErr) {
#endif
		maxrate = rate22khz;

		if (NewSoundManager && Audio16)
			maxbits = 16;
		else
			maxbits = 8;
#if !GENERATING68K || !GENERATINGCFM
	}
#endif

	switch (md_mixfreq) {
	  case 48000:
		rate = rate48khz;
		break;
	  case 44100:
		rate = rate44khz;
		break;
	  case 22254:
		rate = rate22khz;
		break;
	  case 22050:
		rate = rate22050hz;
		break;
	  case 11127:
		rate = rate11khz;
		break;
	  case 11025:
		rate = rate11025hz;
		break;
	  default:
		rate = 0;
		break;
	}

	if (!rate) {
		_mm_errno = MMERR_MAC_SPEED;
		return 1;
	}

	if ((md_mode & DMODE_16BITS) && (maxbits < 16))
		md_mode &= ~DMODE_16BITS;

	if (!Stereo || !StereoMixing)
		md_mode &= ~DMODE_STEREO;

	if (rate > maxrate)
		rate = maxrate;
	if (md_mixfreq > (maxrate >> 16))
		md_mixfreq = maxrate >> 16;

	iErr = SndNewChannel(&soundChannel, sampledSynth,
						(md_mode & DMODE_STEREO) ? initStereo : initMono,
						NULL);
	if (iErr != noErr) {
		_mm_errno = MMERR_OPENING_AUDIO;
		return 1;
	}

	doubleHeader.dbhCompressionID = 0;
	doubleHeader.dbhPacketSize = 0;
	doubleHeader.dbhSampleRate = rate;
	doubleHeader.dbhSampleSize = (md_mode & DMODE_16BITS) ? 16 : 8;
	doubleHeader.dbhNumChannels = (md_mode & DMODE_STEREO) ? 2 : 1;
	doubleHeader.dbhDoubleBack = NewSndDoubleBackProc(&MyDoubleBackProc);

	for (i = 0; i < FRAGMENTS; i++) {
		SndDoubleBufferPtr Buffer;

		Buffer =
		  (SndDoubleBufferPtr) NewPtrClear(sizeof(SndDoubleBuffer) +
										   buffersize);
		if (!Buffer) {
			_mm_errno = MMERR_OUT_OF_MEMORY;
			return 1;
		}

		Buffer->dbNumFrames = 0;
		Buffer->dbFlags = 0;
		Buffer->dbUserInfo[0] = SetCurrentA5();
		Buffer->dbUserInfo[1] = 0;

		doubleHeader.dbhBufferPtr[i] = Buffer;
	}

	return Mixer_Init();
}

static void MAC_Exit(void)
{
	int i;

	SndDisposeChannel(soundChannel, true);
	soundChannel = NULL;

	DisposeRoutineDescriptor((UniversalProcPtr) doubleHeader.dbhDoubleBack);
	doubleHeader.dbhDoubleBack = NULL;

	for (i = 0; i < FRAGMENTS; i++) {
		DisposePtr((Ptr) doubleHeader.dbhBufferPtr[i]);
		doubleHeader.dbhBufferPtr[i] = NULL;
	}

	Mixer_Exit();
}

static BOOL MAC_PlayStart(void)
{
	MyDoubleBackProc(soundChannel, doubleHeader.dbhBufferPtr[0]);
	MyDoubleBackProc(soundChannel, doubleHeader.dbhBufferPtr[1]);

	if (SndPlayDoubleBuffer(soundChannel, &doubleHeader) != noErr) {
		_mm_errno = MMERR_MAC_START;
		return 1;
	}

	return Mixer_PlayStart();
}

static void MAC_PlayStop(void)
{
	SndCommand cmd;

	cmd.cmd = quietCmd;
	cmd.param1 = 0;
	cmd.param2 = 0;
	SndDoImmediate(soundChannel, &cmd);

	cmd.cmd = flushCmd;
	cmd.param1 = 0;
	cmd.param2 = 0;
	SndDoImmediate(soundChannel, &cmd);

	Mixer_PlayStop();
}

static void MAC_Update(void)
{
}

MDRIVER drv_mac = {
	NULL,
	"Mac Driver",
	"Macintosh Sound Manager Driver v1.0",
	256,
	"mac",
	"buffer:r:10,16,12:Audio buffer log2 size\n",

	MAC_CommandLine,
	MAC_IsThere,
	Mixer_SampleLoad,
	Mixer_SampleUnload,
	Mixer_SampleSpace,
	Mixer_SampleLength,
	MAC_Init,
	MAC_Exit,
	NULL,
	Mixer_SetNumVoices,
	MAC_PlayStart,
	MAC_PlayStop,
	MAC_Update,
	NULL,
	Mixer_VoiceSetVolume,
	Mixer_VoiceGetVolume,
	Mixer_VoiceSetFrequency,
	Mixer_VoiceGetFrequency,
	Mixer_VoiceSetPanning,
	Mixer_VoiceGetPanning,
	Mixer_VoicePlay,
	Mixer_VoiceStop,
	Mixer_VoiceStopped,
	Mixer_VoiceGetPosition,
	Mixer_VoiceRealVolume
};

/* ex:set ts=4: */
