/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.
 
	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_nos.c,v 1.1.1.1 2004/01/16 02:13:41 raph Exp $

  Driver for no output

==============================================================================*/

/*

	Written by Jean-Paul Mikkers <mikmak@via.nl>

*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "mikmod_internals.h"

#define ZEROLEN 32768

static SBYTE *zerobuf = NULL;

static BOOL NS_IsThere(void)
{
	return 1;
}

static BOOL NS_Init(void)
{
	zerobuf = (SBYTE *)_mm_malloc(ZEROLEN);
	return Mixer_Init();
}

static void NS_Exit(void)
{
	Mixer_Exit();
	_mm_free(zerobuf);
}

static void NS_Update(void)
{
	if (zerobuf)
		Mixer_WriteBytes(zerobuf, ZEROLEN);
}

MDRIVER drv_nos = {
	NULL,
	"No Sound",
	"Nosound Driver v3.0",
	256,
	"nosound",
	NULL,

	NULL,
	NS_IsThere,
	Mixer_SampleLoad,
	Mixer_SampleUnload,
	Mixer_SampleSpace,
	Mixer_SampleLength,
	NS_Init,
	NS_Exit,
	NULL,
	Mixer_SetNumVoices,
	Mixer_PlayStart,
	Mixer_PlayStop,
	NS_Update,
	NULL,
	Mixer_VoiceSetVolume,
	Mixer_VoiceGetVolume,
	Mixer_VoiceSetFrequency,
	Mixer_VoiceGetFrequency,
	Mixer_VoiceSetPanning,
	Mixer_VoiceGetPanning,
	Mixer_VoicePlay,
	Mixer_VoiceStop,
	Mixer_VoiceStopped,
	Mixer_VoiceGetPosition,
	Mixer_VoiceRealVolume
};


/* ex:set ts=4: */
