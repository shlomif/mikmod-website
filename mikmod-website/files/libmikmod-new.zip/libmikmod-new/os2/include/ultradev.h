/*
    Mikmod maintainer's note : the SDK for the Manley GUS drivers is public
    domain, and came with the following disclaimer:

	Standard Disclaimer
	This code is provided as is. The author (Sander van Leeuwen) isn't
	responsible for any damage that may result from using this code.
*/

/*******************************************************************************
   OS/2 device driver interface to the Gravis Ultrasound family of soundcards 
				6-6-1996
		     Written by Sander van Leeuwen
   	 	       email: sandervl@xs4all.nl
*******************************************************************************/

/* *INDENT-OFF* */
#ifdef __cplusplus
extern "C" {
#endif
/* *INDENT-ON* */

#pragma pack(1)					/* needed for communication with the driver! */
typedef struct {
	short int voice;
	unsigned short int end_idx;	/* end location in ultra DRAM */
	unsigned char rate;			/* 0 to 63 */
	unsigned char mode;			/* mode to run the volume ramp in ... */
} VolumeStruct;

typedef struct {
	short int voice;
	long speed_khz;
} FreqStruct;

typedef struct {
	short int voice;
	unsigned char data;
} BalanceStruct;

typedef struct {
	short int voice;			/* voice to start */
	unsigned long begin;		/* start location in ultra DRAM */
	unsigned long start;		/* start loop location in ultra DRAM */
	unsigned long end;			/* end location in ultra DRAM */
	unsigned char mode;			/* mode to run the voice (loop etc) */
} VoiceStruct;

typedef struct {
	short int timer;
	unsigned char time;
} TimerStruct;

typedef struct {
	unsigned long size;
	unsigned long location;
	unsigned char type;			/* 8 or 16 bit */
} AllocStruct;

typedef struct {
	unsigned long size;
	unsigned long location;
} FreeStruct;

typedef struct {
	long address;
	unsigned char data;
} PokeStruct;

typedef struct {
	short int voice;
	long begin;					/* begin address in RAM */
	long end;
	long distance;				/* distance between read & write  */
	unsigned char balance;
	unsigned int volume;
	unsigned char rate;
	unsigned char mode;			/* mode to run the voice (loop etc) */
} EffectStruct;

typedef struct {
	unsigned char control;
	unsigned long dram_loc;
} XferStruct;

/* always read voice specific registers */
typedef struct {
	short int reg;
	short int voice;
	short int contents;
} PortStruct;

typedef struct {
	long freq;
	short int voice;
	unsigned char balance;
	unsigned short int volume;
	unsigned char rate;
	unsigned char mode;
} AllStruct;

#pragma pack()					/* restore original packing */

APIRET UltraOpen(int cardno);
APIRET UltraClose();
APIRET UltraGetHandle(int *);
APIRET UltraSetNVoices(int);
APIRET UltraEnableOutput(void);
APIRET UltraDisableOutput(void);
APIRET UltraBlockTimerHandler1();
APIRET UltraBlockTimerHandler2();
APIRET UltraUnblockAll(void);
APIRET UltraStartTimer(int, int);
APIRET UltraStopTimer(int);
APIRET UltraSetBalance(int, int);
APIRET UltraSetFrequency(int, int);
APIRET UltraSetAll(int, char, int, int, unsigned char, unsigned char);
APIRET UltraPokeData(long, int);
APIRET UltraPeekData(int *);
APIRET UltraMemAlloc(unsigned long, unsigned long *, unsigned char);
APIRET UltraMemFree(int, int);
APIRET UltraMemInit(void);
APIRET UltraSizeDram(int *);
APIRET UltraStartVoice(int, unsigned int, unsigned int, unsigned int,
					   unsigned char);
APIRET UltraStopVoice(int);
APIRET UltraVectorLinearVolume(int, unsigned int, unsigned char,
							   unsigned char);
APIRET UltraDownload(void *, unsigned char, unsigned long, unsigned int, int);
APIRET UltraGetAccess(void);
APIRET UltraReleaseAccess(void);
APIRET UltraGetDriverVersion(int *);
APIRET UltraSetLoopMode(int, int);
APIRET UltraVoiceStopped(int *);
APIRET UltraSetLoopStart(int, unsigned int);
APIRET UltraGetUltraType(int *);

APIRET UltraAddEffectToVoice(int, int);
APIRET UltraRemoveEffectFromVoice(int, int);
APIRET UltraStartEffectVoice(int, int, int, int, int, int, int, int);

/* Type of samples needed for UltraDownload (control byte) */
#define DMA_16          	0x40	/* 16 bits sample */
#define DMA_8           	0x00	/* 8 bits sample */

#define DMA_CVT_2       	0x80	/* unsigned data */
#define DMA_NO_CVT      	0x00	/* signed data */

/* ($0,$80) Voice control register */
#define VOICE_STOPPED		0x01	/* voice has stopped */
#define STOP_VOICE			0x02	/* stop voice */
#define VC_DATA_TYPE		0x04	/* 0=8 bit,1=16 bit */
#define VC_LOOP_ENABLE		0x08	/* 1=enable */
#define VC_BI_LOOP			0x10	/* 1=bi directional looping */
#define VC_WAVE_IRQ			0x20	/* 1=enable voice's wave irq */
#define VC_DIRECT			0x40	/* 0=increasing,1=decreasing */
#define VC_IRQ_PENDING		0x80	/* 1=wavetable irq pending */

/* ($0,$8D) Volume control register */
#define	VOLUME_STOPPED		0x01	/* volume has stopped */
#define	STOP_VOLUME			0x02	/* stop volume */
#define	VL_ROLLOVER			0x04	/* Roll PAST end & gen IRQ */
#define	VL_LOOP_ENABLE		0x08	/* 1=enable */
#define	VL_BI_LOOP			0x10	/* 1=bi directional looping */
#define	VL_IRQ				0x20	/* 1=enable voice's volume irq */
#define	VL_BACKWARD			0x40	/* 0=increasing, 1=decreasing */
#define	VL_IRQ_PENDING		0x80	/* 1=wavetable irq pending */

/* Values returned by UltraGetUltraType */
#define GUS_VER_PLAIN		1	/* Analog switches only */
#define GUS_VER_ICS2101FLR	2	/* 2101 with some left/right flip problems */
#define GUS_VER_ICS2101		3	/* ICS2101 with analog switches */
#define GUS_VER_CS4231		4	/* CS4231 with analog switches */
#define GUS_VER_ACE			5	/* Ace has no mixer capabilities at all */
#define GUS_VER_CD3			6	/* Same as ICS2101 */
#define GUS_VER_ICS2102		7	/* ICS2102 with analog switches */
#define GUS_VER_MAX23		8	/* CS4231 without analog switches */
#define GUS_VER_CS4231_DB	9	/* RJM: added this */
#define GUS_VER_PNP			11	/* SvL: UltraSound Plug 'n Play (Pro) */
#define GUS_VER_UNKNOWN		-1	/* Driver doesn't support GetUltraType */

/* *INDENT-OFF* */
#ifdef __cplusplus
};
#endif
/* *INDENT-ON* */

/* ex:set ts=4: */
