/* config.h.in.  Generated manually for OS/2 with GCC/EMX.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS

/* Define if your system supports binary pipes (i.e. Unix) */
#undef DRV_PIPE

/* We want the DART driver */
#define DRV_DART
/* We want the OS/2 MMOS2 driver */
#define DRV_OS2
/* We want the Gravis Ultrasound driver */
#define DRV_ULTRA

/* Define if you want a debug version of the library */
#undef MIKMOD_DEBUG

/* Define if you have the setenv function.  */
#define HAVE_SETENV

/* Define if you have the snprintf function.  */
#define HAVE_SNPRINTF

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H
