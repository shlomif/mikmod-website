/*
    Mikmod maintainer's note : the SDK for the Manley GUS drivers is public
    domain (its gotos are, too), and came with the following disclaimer:

	Standard Disclaimer
	This code is provided as is. The author (Sander van Leeuwen) isn't
	responsible for any damage that may result from using this code.
*/

/*******************************************************************************
   OS/2 device driver interface to the Gravis Ultrasound family of soundcards 
				6-6-1996
		     Written by Sander van Leeuwen
   	 	       email: sandervl@xs4all.nl
*******************************************************************************/

#include <string.h>
#include <stdio.h>

#define INCL_DOSDEVICES
#include <os2.h>
#include "ultradev.h"

/* IOCTL commands */
#define GUS_COMMANDS					0x0F

#define UltraDevStartEffectVoice		0x4B
#define UltraDevAddEffectToVoice		0x4C
#define UltraDevRemoveEffectFromVoice   0x4D
#define UltraDevGetUltraType			0x4E

#define UltraDevSetNVoices				0x50
#define UltraDevEnableOutput			0x51
#define UltraDevDisableOutput			0x52
#define UltraDevPokeData				0x53
#define UltraDevPeekData				0x54
#define UltraDevMemAlloc				0x55
#define UltraDevMemFree					0x56
#define UltraDevMemInit					0x57
#define UltraDevStartTimer				0x58
#define UltraDevStopTimer				0x59
#define UltraDevBlockTimerHandler1		0x5A
#define UltraDevBlockTimerHandler2		0x5B
#define UltraDevStartVoice				0x5C
#define UltraDevStopVoice				0x5D
#define UltraDevSetBalance				0x5E
#define UltraDevSetFrequency			0x5F
#define UltraDevVectorLinearVolume		0x60
#define UltraDevPrepare4DMAXfer			0x61
#define UltraDevUnblockAll				0x62
#define UltraDevSetAll					0x63

#define UltraDevGetAccess   	        0x6A
#define UltraDevReleaseAccess  	        0x6B
#define UltraDevGetRegStatus	        0x6C
#define UltraDevSizeDRAM				0x6D
#define UltraDevGetDriverVersion		0x6E
#define UltraDevStopAll					0x6F

#define UltraDevSetLoopMode				0x73
#define UltraDevVoiceStopped			0x74

#define UltraDevSetLoopStart			0x78
static HFILE GUSHandle;

/******************************************************************************/
APIRET UltraOpen(int cardno)
{
	APIRET status;
	ULONG action;
	char devname[20];
	sprintf(devname, "ULTRA%d$", cardno + 1);
	status =
	  DosOpen(devname, &GUSHandle, &action, 0, FILE_NORMAL, FILE_OPEN,
			  OPEN_ACCESS_READWRITE | OPEN_SHARE_DENYNONE |
			  OPEN_FLAGS_WRITE_THROUGH, NULL);
	if (status) {
		GUSHandle = 0;
		return status;
	}
	return 0;
}

APIRET UltraClose()
{
	if (GUSHandle) {
		DosClose(GUSHandle);
		GUSHandle = 0;
	}
	return 0;
}
APIRET UltraGetHandle(int *handle)
{
	*handle = GUSHandle;
	return 0;
}
APIRET UltraSetNVoices(int numvoices)
{
	ULONG ParmLength = 0, DataLength = 4;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetNVoices, NULL, 0,
			 &ParmLength, &numvoices, 4, &DataLength));
}
APIRET UltraGetAccess()
{
	ULONG DataLength = 0, ParmLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevGetAccess, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraReleaseAccess()
{
	ULONG DataLength = 0, ParmLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevReleaseAccess, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraEnableOutput()
{
	ULONG DataLength = 0, ParmLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevEnableOutput, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraDisableOutput()
{
	ULONG DataLength = 0, ParmLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevDisableOutput, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraBlockTimerHandler1()
{
	ULONG ParmLength = 0, DataLength = 0;

	/* block until timer1 interrupt */
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevBlockTimerHandler1, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraBlockTimerHandler2()
{
	ULONG ParmLength = 0, DataLength = 0;

	/* block until timer2 interrupt */
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevBlockTimerHandler2, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraStartTimer(int timer, int time)
{
	TimerStruct tbuffer;
	ULONG ParmLength, DataLength;
	ParmLength = 0;
	DataLength = sizeof(TimerStruct);
	tbuffer.timer = (short int)timer;
	tbuffer.time = (unsigned char)time;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevStartTimer, NULL, 0,
			 &ParmLength, &tbuffer, DataLength, &DataLength));
}
APIRET UltraStopTimer(int timer)
{
	ULONG ParmLength, DataLength;
	ParmLength = 0;
	DataLength = 4;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevStopTimer, NULL, 0,
			 &ParmLength, &timer, 4, &DataLength));
}
APIRET UltraSetBalance(int voice, int data)
{
	ULONG ParmLength = 0, DataLength;
	BalanceStruct bbuffer;
	DataLength = sizeof(BalanceStruct);
	bbuffer.voice = (short int)voice;
	bbuffer.data = (unsigned char)data;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetBalance, NULL, 0,
			 &ParmLength, &bbuffer, DataLength, &DataLength));
}
APIRET UltraSetFrequency(int voice, int freq)
{
	ULONG ParmLength = 0, DataLength;
	FreqStruct fbuffer;
	DataLength = sizeof(FreqStruct);
	fbuffer.voice = (short int)voice;
	fbuffer.speed_khz = freq;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetFrequency, NULL, 0,
			 &ParmLength, &fbuffer, DataLength, &DataLength));
}
APIRET UltraMemFree(int size, int location)
{
	ULONG ParmLength = 0, DataLength = sizeof(AllocStruct);
	AllocStruct abuffer;
	abuffer.size = size;
	abuffer.location = location;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevMemFree, NULL, 0, &ParmLength,
			 &abuffer, DataLength, &DataLength));
}

/* type = VC_DATA_TYPE = 16 bit, otherwise 8 bit */
APIRET UltraMemAlloc(unsigned long size, unsigned long *location,
					 unsigned char type)
{
	ULONG ParmLength = 0, DataLength;
	AllocStruct abuffer;
	APIRET rc;
	DataLength = sizeof(AllocStruct);
	abuffer.size = size;
	abuffer.location = *location;
	abuffer.type = type;
	rc =
	  DosDevIOCtl(GUSHandle, GUS_COMMANDS, UltraDevMemAlloc, NULL, 0,
				  &ParmLength, &abuffer, DataLength, &DataLength);
	*location = abuffer.location;	/* location in DRAM GUS */
	return (rc);
}
APIRET UltraMemInit()
{
	ULONG ParmLength = 0, DataLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevMemAlloc, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraDownload(void *dataptr, unsigned char control,
					 unsigned long dram_loc, unsigned int size, int wait)
{
	ULONG ParmLength = 0, DataLength;
	APIRET rc;
	ULONG written;
	XferStruct xbuffer;
	char *Buffer64k;

	/* structure voor UltraPrepare4DMAXfer IOCtl call */
	DataLength = sizeof(XferStruct);
	xbuffer.control = control;	/* control byte (data width, signed/unsigned) */
	xbuffer.dram_loc = dram_loc;

	/* NEED to allocate a buffer to transfer samples > 64 kb !!! */
	rc = DosAllocMem((PPVOID) & Buffer64k, 64 * 1024, PAG_COMMIT | PAG_WRITE);
	if (rc)
		return (TRUE);
	while (TRUE) {
		if (size > 64000) {		/* 16 bit segments in a 32 bit world 8( */
			memcpy(Buffer64k, dataptr, 64000);
			rc =
			  DosDevIOCtl(GUSHandle, GUS_COMMANDS, UltraDevPrepare4DMAXfer,
						  NULL, 0, &ParmLength, &xbuffer, DataLength,
						  &DataLength); if (rc != 0)
				goto download_err;
			rc = DosWrite(GUSHandle, Buffer64k, 64000, &written);
			if (rc != 0)
				goto download_err;
			dram_loc += 64000;
			xbuffer.dram_loc = dram_loc;
			xbuffer.control = control;
			(unsigned char *)dataptr += 64000;
			size -= 64000;
		}

		else
			break;
	}
	if (size > 0) {
		memcpy(Buffer64k, dataptr, size);
		rc =
		  DosDevIOCtl(GUSHandle, GUS_COMMANDS, UltraDevPrepare4DMAXfer, NULL,
					  0, &ParmLength, &xbuffer, DataLength, &DataLength);
		if (rc != 0)
			goto download_err;
		rc = DosWrite(GUSHandle, Buffer64k, size, &written);	/* last transfer */
		if (rc)
			goto download_err;
	}
	DosFreeMem(Buffer64k);
	return (0);
  download_err:
	DosFreeMem(Buffer64k);
	return (rc);
}
APIRET UltraPokeData(long address, int data)
{
	ULONG ParmLength = 0, DataLength;
	PokeStruct pbuffer;
	pbuffer.address = address;
	pbuffer.data = (unsigned char)data;
	DataLength = sizeof(pbuffer);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevPokeData, NULL, 0,
			 &ParmLength, &pbuffer, DataLength, &DataLength));
}
APIRET UltraPeekData(int *address)
{
	ULONG ParmLength = 0, DataLength;
	DataLength = sizeof(int);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevPeekData, NULL, 0,
			 &ParmLength, address, DataLength, &DataLength));
}
APIRET UltraUnblockAll()
{
	ULONG ParmLength = 0, DataLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevUnblockAll, NULL, 0,
			 &ParmLength, NULL, 0, &DataLength));
}
APIRET UltraStopVoice(int c)
{
	ULONG ParmLength = 0, DataLength = 2;
	short int voice;
	voice = (short int)c;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevStopVoice, NULL, 0,
			 &ParmLength, &voice, DataLength, &DataLength));
}

/* voice:   voice number
 * end_idx: final volume
 * rate:    volume ramp rate (0x00..0x3f..0xc1)
 * mode:    volume ramp mode (loop, etc)
 */
APIRET UltraVectorLinearVolume(int voice, unsigned int end_idx,
							   unsigned char rate, unsigned char mode)
{
	ULONG ParmLength, DataLength;
	VolumeStruct vbuffer;
	vbuffer.voice = (short int)voice;
	vbuffer.end_idx = (short int)end_idx;
	vbuffer.rate = rate;
	vbuffer.mode = mode;
	DataLength = sizeof(VolumeStruct);
	ParmLength = 0;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevVectorLinearVolume, NULL, 0,
			 &ParmLength, &vbuffer, DataLength, &DataLength));
}
APIRET UltraSetAll(int voice, char balance, int freq, int volume,
				   unsigned char rate, unsigned char mode)
{
	ULONG ParmLength = 0, DataLength;
	AllStruct abuffer;
	DataLength = sizeof(AllStruct);
	abuffer.voice = (short int)voice;
	abuffer.balance = (unsigned char)balance;
	abuffer.freq = freq;
	abuffer.volume = (unsigned short int)volume;
	abuffer.rate = rate;
	abuffer.mode = mode;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetAll, NULL, 0, &ParmLength,
			 &abuffer, DataLength, &DataLength));
}

/* gusvoice: voice to start
 * begin: start location in ultra DRAM
 * start: start loop location in ultra DRAM
 * end: end location in ultra DRAM
 * mode: mode to run the voice (loop etc)
 */
APIRET UltraStartVoice(int gusvoice, unsigned int begin, unsigned int start,
					   unsigned int end, unsigned char mode)
{
	ULONG ParmLength = 0, DataLength;
	VoiceStruct voice;
	voice.voice = (short int)gusvoice;
	voice.begin = begin;
	voice.start = start;
	voice.end = end;
	voice.mode = mode;
	DataLength = sizeof(VoiceStruct);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevStartVoice, NULL, 0,
			 &ParmLength, &voice, DataLength, &DataLength));
}

/* gusvoice: voice to start
 * start: start loop location in ultra DRAM
 */
APIRET UltraSetLoopStart(int gusvoice, unsigned int start)
{
	ULONG ParmLength = 0, DataLength;
	VoiceStruct voice;
	voice.voice = (short int)gusvoice;
	voice.start = start;
	DataLength = sizeof(VoiceStruct);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetLoopMode, NULL, 0,
			 &ParmLength, &voice, DataLength, &DataLength));
}
APIRET UltraSizeDram(int *size)
{
	ULONG ParmLength = 0, DataLength;
	DataLength = sizeof(int);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSizeDRAM, NULL, 0,
			 &ParmLength, size, DataLength, &DataLength));
}

/* version: High word contains major version, low word minor version */
APIRET UltraGetDriverVersion(int *version)
{
	ULONG ParmLength = 0, DataLength;
	DataLength = sizeof(int);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevGetDriverVersion, NULL, 0,
			 &ParmLength, version, DataLength, &DataLength));
}
APIRET UltraSetLoopMode(int voice, int mode)
{
	ULONG ParmLength = 0, DataLength;
	BalanceStruct bbuffer;
	DataLength = sizeof(BalanceStruct);
	bbuffer.voice = (short int)voice;
	bbuffer.data = (unsigned char)mode;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevSetLoopMode, NULL, 0,
			 &ParmLength, &bbuffer, DataLength, &DataLength));
}
APIRET UltraVoiceStopped(int *voice)
{
	ULONG ParmLength = 0, DataLength;
	DataLength = sizeof(int);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevVoiceStopped, NULL, 0,
			 &ParmLength, voice, DataLength, &DataLength));
}
APIRET UltraGetUltraType(int *type)
{
	ULONG ParmLength = 0, DataLength;
	DataLength = sizeof(int);
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevGetUltraType, NULL, 0,
			 &ParmLength, type, DataLength, &DataLength));
}
APIRET UltraAddEffectToVoice(int voice, int effect)
{
	ULONG ParmLength = 0, DataLength, effdata;
	DataLength = 4;
	effdata = (effect << 16) + voice;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevAddEffectToVoice, NULL, 0,
			 &ParmLength, &effdata, DataLength, &DataLength));
}
APIRET UltraRemoveEffectFromVoice(int voice, int effect)
{
	ULONG ParmLength = 0, DataLength, effdata;
	DataLength = 4;
	effdata = (effect << 16) + voice;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevRemoveEffectFromVoice, NULL,
			 0, &ParmLength, &effdata, DataLength, &DataLength));
}
APIRET UltraStartEffectVoice(int voice, int begin, int end, int distance,
							 int balance, int volume, int rate, int mode)
{
	ULONG ParmLength = 0, DataLength = sizeof(EffectStruct);
	EffectStruct eff_buffer;
	eff_buffer.voice = voice;
	eff_buffer.begin = begin;
	eff_buffer.end = end;
	eff_buffer.distance = distance;
	eff_buffer.balance = balance;
	eff_buffer.volume = volume;
	eff_buffer.rate = rate;
	eff_buffer.mode = mode;
	return (DosDevIOCtl
			(GUSHandle, GUS_COMMANDS, UltraDevStartEffectVoice, NULL, 0,
			 &ParmLength, &eff_buffer, DataLength, &DataLength));
}

/* ex:set ts=4: */
