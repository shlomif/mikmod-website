/*	MikMod sound library
	(c) 1998, 1999 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is free software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.

	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: os2gus.c,v 1.1.1.1 2004/01/16 02:13:24 raph Exp $

  Driver for GUS cards under OS/2

==============================================================================*/

/*

	Written by Andrew Zabolotny <bit@eltech.ru>

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INCL_DOS
#include <os2.h>
#include "ultradev.h"
#include "libgus.h"

/* Debug macros */
#ifdef MIKMOD_DEBUG
#define DEBUG_PRINT(x) printf x
#else
#define DEBUG_PRINT(x)
#endif

/* To avoid clicks we'll ramp to given volume instead of directly setting it */
#define GUS_VOLCHANGE_RAMP	0x3f	/* Volume change ramp (quick) */

typedef void (*__gus_callback) ();

/* Private structure to keep track of current GUS state */
struct {
	unsigned char open;			/* 1 if between gus_open() and gus_close() */
	unsigned char interwave;	/* GUS InterWave card */
	unsigned char cmd_voice;	/* Pool selection index cache */
	unsigned int cmd_pool_top;	/* Command pool top */
	unsigned char *cmd_pool;	/* Async commands pool */
	unsigned char cmd_pool_ready;	/* Set to 1 so that pool gets flushed */
	HEV cmd_pool_flushed;		/* Triggered as soon as pool is freed */
	volatile unsigned int wait_count;	/* Decremented on each timer tick */
	HEV wait_finished;			/* Triggered as soon as wait_count reaches zero */
	unsigned int version;		/* GUS version */
	unsigned int ram;			/* Amount of GUS RAM in Kb */
	unsigned int freeram;		/* Amount of free RAM */
	unsigned int freq;			/* Current mixing frequency */
	unsigned int voices;		/* Number of active voices */
	unsigned int card;			/* GUS sound card number */
	unsigned int dynmask;		/* Dynamically allocated voices mask */
	gus_instrument_t *instr;	/* The list of registered instruments */
	unsigned int tid;			/* GUS update thread ID (blocking on timer1) */
	unsigned char timer1;		/* 1 if timer1 is active */
	unsigned int t1_base;		/* Timer 1 base in percents (def: 100) */
	unsigned int t1_counter;	/* Timer 1 counter */
	unsigned int t1_multiple;	/* Timer 1 multiple */
	unsigned int t1_countdown;	/* Decremented from t1_multiple to zero */
	unsigned int t1_count;		/* Incremented on each timer 1 tick */
	__gus_callback t1_callback;	/* Called once per timer 1 tick */
} gus;

/* Commands are pooled and executed ON TIMER (1st timer) interrupt.
 * Currently there is a limit on the number of commands that you can
 * issue between gus_do_flush (...); this should not be an issue however
 * because each voice has a limited (little) set of parameters that
 * you can change (freq, vol, pan... what else?)
 *
 * The pool is a pseudo-CPU code that gets executed once per timer interrupt.
 */

/* Below are definitions for commands placed in a per-voice pool */
#define PCMD_NOP			0x00	/* Traditionally ... */
#define PCMD_VOICE			0x01	/* +B: select voice */
#define PCMD_START			0x02	/* +L: start voice */
#define PCMD_STOP			0x03	/*     stop voice */
#define PCMD_FREQ			0x04	/* +W: set frequence */
#define PCMD_VOLUME			0x05	/* +W: set volume */
#define PCMD_PAN			0x06	/* +B: set panning */
#define PCMD_OFFSET			0x07	/* +L: set DRAM offset */
#define PCMD_STOP_LOOP		0x08	/*     stop looping */

/* Inline routines for working with command pool */

/* WARNING: no bounds checking due to performance reasons */
#define __POOL_VALUE(type,value)								\
  *((unsigned type *)&gus.cmd_pool [gus.cmd_pool_top]) = value;	\
  gus.cmd_pool_top += sizeof (type);

static inline void __pool_command(unsigned char command)
{
	__POOL_VALUE(char, command);
}

static inline void __pool_command_b(unsigned char command, unsigned char arg)
{
	__POOL_VALUE(char, command);
	__POOL_VALUE(char, arg);
}

static inline void __pool_command_w(unsigned char command, unsigned short arg)
{
	__POOL_VALUE(char, command);
	__POOL_VALUE(short, arg);
}

static inline void __pool_command_l(unsigned char command, unsigned long arg)
{
	__POOL_VALUE(char, command);
	__POOL_VALUE(long, arg);
}

static inline void __pool_select_voice(unsigned char voice)
{
	if (gus.cmd_voice != voice)
		__pool_command_b(PCMD_VOICE, gus.cmd_voice = voice);
}

#undef __POOL_VALUE

static void __gus_kick(int voice, gus_wave_t * wave, unsigned char *vc,
					   unsigned long wave_offset)
{
	unsigned long wbegin, wstart, wend;
	*vc = 0;
	if (wave->format & GUS_WAVE_16BIT)
		*vc |= VC_DATA_TYPE;
	if (wave->format & GUS_WAVE_BACKWARD)
		*vc |= VC_BI_LOOP;
	if (wave->format & GUS_WAVE_LOOP) {
		*vc |= VC_LOOP_ENABLE;
		if (wave->format & GUS_WAVE_BIDIR)
			*vc |= VC_BI_LOOP;
	}
	wstart = wave->begin.memory + (wave->loop_start >> 4);
	wend = wave->begin.memory + ((wave->format & GUS_WAVE_LOOP) ?
								 (wave->loop_end >> 4) : wave->size) - 1;
	wbegin = wave->begin.memory + wave_offset;

	UltraStartVoice(voice, wbegin, wstart, wend, *vc);
}

static void __gus_timer_thread()
{
	unsigned char *src, *top;
	int i, cur_voice = -1;
	unsigned short cur_freq[32], new_freq[32];
	unsigned short cur_vol[32], new_vol[32];
	unsigned char cur_pan[32], new_pan[32];
	unsigned char cur_vcmode[32];
	unsigned char voice_flag[32];
	gus_wave_t *cur_wave[32];
	unsigned long wave_offset[32];

#define VOICE_FLAG_KICK			1
#define VOICE_FLAG_STOP			2
#define VOICE_FLAG_STOP_LOOP	3

	/* Raise the priority of this thread to timecritical */
	DosSetPriority(PRTYS_THREAD, PRTYC_TIMECRITICAL, PRTYD_MAXIMUM - 1, 0);

	/* Initialize current voice state variables */
	memset(&cur_freq, 0, sizeof(cur_freq));
	memset(&new_freq, 0, sizeof(new_freq));
	memset(&cur_vol, 0, sizeof(cur_vol));
	memset(&new_vol, 0, sizeof(new_vol));
	memset(&cur_pan, 0, sizeof(cur_pan));
	memset(&new_pan, 0, sizeof(new_pan));
	memset(&cur_vcmode, 0, sizeof(cur_vcmode));
	memset(&voice_flag, 0, sizeof(voice_flag));
	memset(&cur_wave, 0, sizeof(cur_wave));

	for (;;) {
		/* Wait for timer tick event */
		if (UltraBlockTimerHandler1())
			DosSleep(1);		/* If an error occured, let other threads run */

		/* If gus card is closed, quit */
		if (!gus.open) {
			gus.tid = 0;
			_endthread();
		}

		/* Do voice post-processing here */
		for (i = 0; i < 32; i++)
			switch (voice_flag[i]) {
			  case VOICE_FLAG_STOP:
				voice_flag[i] = 0;
				UltraStopVoice(i);
				break;
			  case VOICE_FLAG_KICK:
				voice_flag[i] = 0;
				__gus_kick(i, cur_wave[i], &cur_vcmode[i], wave_offset[i]);
				wave_offset[i] = 0;
				UltraVectorLinearVolume(i, cur_vol[i], GUS_VOLCHANGE_RAMP, 0);
				break;
			}

		if (!--gus.t1_countdown)
			gus.t1_countdown = gus.t1_multiple;
		else
			continue;

		gus.t1_count++;

		if (gus.wait_count)
			if (!--gus.wait_count)
				DosPostEventSem(gus.wait_finished);

		if (gus.t1_callback)
			gus.t1_callback();

		if (!gus.cmd_pool_ready)
			continue;

		memset(&wave_offset, 0, sizeof(wave_offset));

		src = gus.cmd_pool;
		top = gus.cmd_pool + gus.cmd_pool_top;

#define GET_B	*src
#define GET_W	*((unsigned short *)src)
#define GET_L	*((unsigned long *)src)

		while (src < top)
			switch (GET_B++) {
			  case PCMD_VOICE:
				cur_voice = GET_B++;
				break;
			  case PCMD_FREQ:
				new_freq[cur_voice] = GET_W++;
				break;
			  case PCMD_PAN:
				new_pan[cur_voice] = GET_B++;
				break;
			  case PCMD_VOLUME:
				new_vol[cur_voice] = GET_W++;
				break;
			  case PCMD_OFFSET:
				wave_offset[cur_voice] = GET_L++;
				break;
			  case PCMD_START:
				cur_wave[cur_voice] = (gus_wave_t *) GET_L++;
				voice_flag[cur_voice] = VOICE_FLAG_KICK;
				break;
			  case PCMD_STOP:
				new_vol[cur_voice] = 0;
				voice_flag[cur_voice] = VOICE_FLAG_STOP;
				break;
			  case PCMD_STOP_LOOP:
				voice_flag[cur_voice] = VOICE_FLAG_STOP_LOOP;
				break;
			  default:
				/* Alarm! Break out immediately */
				src = top;
				break;
			}

		gus.cmd_pool_ready = 0;
		gus.cmd_pool_top = 0;

		/* Now update all voice parameters */
		for (i = 0; i < 32; i++) {
			unsigned int mask = 0;

			if (cur_freq[i] != new_freq[i])
				mask |= 1;
			if ((cur_vol[i] != new_vol[i]) &&
				(voice_flag[i] != VOICE_FLAG_KICK)) mask |= 2;
			if (cur_pan[i] != new_pan[i])
				mask |= 4;
			cur_freq[i] = new_freq[i];
			cur_vol[i] = new_vol[i];
			cur_pan[i] = new_pan[i];

			if (mask == 7)
				UltraSetAll(i, cur_pan[i], cur_freq[i], cur_vol[i],
							GUS_VOLCHANGE_RAMP, 0);
			else {
				if (mask & 1)
					UltraSetFrequency(i, cur_freq[i]);
				if (mask & 2)
					UltraVectorLinearVolume(i, cur_vol[i], GUS_VOLCHANGE_RAMP,
											0);
				if (mask & 4)
					UltraSetBalance(i, cur_pan[i]);
			}

			switch (voice_flag[i]) {
			  case VOICE_FLAG_KICK:
				if (cur_wave[i] && cur_vol[i])
					UltraVectorLinearVolume(i, 0, GUS_VOLCHANGE_RAMP, 0);
				else {
					voice_flag[i] = 0;
					__gus_kick(i, cur_wave[i], &cur_vcmode[i],
							   wave_offset[i]);
					wave_offset[i] = 0;
					UltraVectorLinearVolume(i, cur_vol[i], GUS_VOLCHANGE_RAMP,
											0);
				}
				break;
			  case VOICE_FLAG_STOP_LOOP:
				voice_flag[i] = 0;
				UltraSetLoopMode(i, 0);
				break;
			}
		}

#undef GET_B
#undef GET_W
#undef GET_L

		DosPostEventSem(gus.cmd_pool_flushed);
	}
}

/************************************************** Middle-level routines *****/

static int __gus_instrument_free(gus_instrument_t * instrument)
{
	gus_instrument_t **cur_instr;
	gus_layer_t *cur_layer;
	gus_wave_t *cur_wave, *wave_head;

	/* Remove the instrument from the list of registered instruments */
	cur_instr = (gus_instrument_t **) & gus.instr;
	while (*cur_instr) {
		if (*cur_instr == instrument) {
			*cur_instr = instrument->next;
			goto instr_loaded;
		}
		cur_instr = &(*cur_instr)->next;
	}
	return -1;

  instr_loaded:

	wave_head = NULL;
	for (cur_layer = instrument->info.layer; cur_layer;
		 cur_layer = cur_layer->next)
		/* Free all waves */
		for (cur_wave = cur_layer->wave; cur_wave; cur_wave = cur_wave->next) {
			if (!wave_head)
				wave_head = cur_wave;
			if (cur_wave->begin.memory != (unsigned int)-1) {
				UltraMemFree(cur_wave->size, cur_wave->begin.memory);
				gus.freeram += cur_wave->size;
			}
		}
	if (wave_head) {
		free(wave_head);
		wave_head = NULL;
	}

	free(instrument->info.layer);
	if (instrument->name)
		free(instrument->name);
	free(instrument);
	return 0;
}

static gus_instrument_t *__gus_instrument_get(int program)
{
	gus_instrument_t *cur_instr = (gus_instrument_t *) gus.instr;
	while (cur_instr) {
		if (cur_instr->number.instrument == program)
			return cur_instr;
		cur_instr = cur_instr->next;
	}
	return NULL;
}

static gus_instrument_t *__gus_instrument_copy(gus_instrument_t * instrument)
{
	gus_instrument_t **cur_instr, *instr;
	gus_layer_t *cur_layer, *dest_layer;
	gus_wave_t *cur_wave, *dest_wave;
	unsigned int waves, layers;

	if (!instrument || !instrument->info.layer || !gus.open)
		return NULL;

	if (__gus_instrument_get(instrument->number.instrument))
		return NULL;

	instr = malloc(sizeof(gus_instrument_t));
	*instr = *instrument;

	if (instrument->name)
		instr->name = strdup(instrument->name);

	/* Make a copy of all layers at once */
	for (layers = 0, cur_layer = instrument->info.layer; cur_layer; layers++)
		cur_layer = cur_layer->next;

	if (!
		(dest_layer = instr->info.layer =
		 malloc(sizeof(gus_layer_t) * layers))) {
		if (instr->name)
			free(instr->name);
		free(instr);
		return NULL;
	}
	for (waves = 0, cur_layer = instrument->info.layer; cur_layer;
		 cur_layer = cur_layer->next) {
		*dest_layer = *cur_layer;
		dest_layer->wave = NULL;
		/* Count the total number of waves */
		for (cur_wave = cur_layer->wave; cur_wave; cur_wave = cur_wave->next)
			waves++;
		if (cur_layer->next)
			dest_layer->next = dest_layer + 1;
		else
			dest_layer->next = NULL;
		dest_layer++;
	}

	/* Allocate memory for waves */
	if (!(dest_wave = malloc(sizeof(gus_wave_t) * waves))) {
		free(instr->info.layer);
		if (instr->name)
			free(instr->name);
		free(instr);
		return NULL;
	}
	for (cur_layer = instrument->info.layer, dest_layer = instr->info.layer;
		 cur_layer;
		 cur_layer = cur_layer->next, dest_layer = dest_layer->next)
		/* Copy all waves */
		for (cur_wave = cur_layer->wave; cur_wave; cur_wave = cur_wave->next) {
			if (!dest_layer->wave)
				dest_layer->wave = dest_wave;

			*dest_wave = *cur_wave;
			/* Mark DRAM address as unallocated */
			dest_wave->begin.memory = -1;

			if (cur_wave->next)
				dest_wave->next = (dest_wave + 1);
			else
				dest_wave->next = NULL;
			dest_wave++;
		}

	/* Insert the instrument into list of registered instruments */
	cur_instr = (gus_instrument_t **) & gus.instr;
	while (*cur_instr)
		cur_instr = &(*cur_instr)->next;
	*cur_instr = instr;

	return instr;
}

static void __gus_instruments_clear()
{
	gus_instrument_t *next_instr, *cur_instr = (gus_instrument_t *) gus.instr;
	while (cur_instr) {
		next_instr = cur_instr->next;
		__gus_instrument_free(cur_instr);
		cur_instr = next_instr;
	}
}

/******************************************************* libGUS interface *****/

/* return value:      number of GUS cards installed in system */
int gus_cards()
{
	int cardno;
	for (cardno = 0; cardno < 8; cardno++)
		if (UltraOpen(cardno))
			break;
		else
			UltraClose();

	return cardno;
}

int gus_open(int card, size_t queue_buffer_size, int non_block)
/* ARGSUSED */
{
	if (UltraOpen(card))
		return -1;

	if (UltraGetAccess()) {
		UltraClose();
		return -1;
	}

	/* Create a event semaphore kicked as soon as command pool is flushed */
	if (DosCreateEventSem(NULL, &gus.cmd_pool_flushed, 0, FALSE)) {
		UltraReleaseAccess();
		UltraClose();
		return -1;
	}

	if (DosCreateEventSem(NULL, &gus.wait_finished, 0, FALSE)) {
		DosCloseEventSem(gus.cmd_pool_flushed);
		UltraReleaseAccess();
		UltraClose();
		return -1;
	}

	/* Start timer thread */
	gus.tid = _beginthread(__gus_timer_thread, NULL, 0x4000, NULL);
	if (!gus.tid) {
		DosCloseEventSem(gus.wait_finished);
		DosCloseEventSem(gus.cmd_pool_flushed);
		UltraReleaseAccess();
		UltraClose();
		return -1;
	}

	/* Allocate and lock command pool buffer */
	if (queue_buffer_size < 64)
		queue_buffer_size = 64;
	if (queue_buffer_size > 16384)
		queue_buffer_size = 16384;
	gus.cmd_pool = malloc(queue_buffer_size);

	gus.open++;
	gus.card = card;
	gus.cmd_voice = -1;

	gus_reset(14, 0);
	gus_do_tempo(60);			/* Default is 60 Hz */

	/* Query some low-level information */
	gus.interwave = 0;
	if (UltraGetUltraType(&gus.version))
		gus.version = GUS_VER_UNKNOWN;
	else
		switch (gus.version) {
		  case GUS_VER_PLAIN:
			gus.version = GUS_CARD_VERSION_CLASSIC;
			break;
		  case GUS_VER_ICS2101FLR:
		  case GUS_VER_ICS2101:
		  case GUS_VER_CD3:
			gus.version = GUS_CARD_VERSION_CLASSIC_ICS;
			break;
		  case GUS_VER_CS4231:
		  case GUS_VER_CS4231_DB:
			gus.version = GUS_CARD_VERSION_EXTREME;
			break;
		  case GUS_VER_ICS2102:
			gus.version = GUS_CARD_VERSION_MAX;
			break;
		  case GUS_VER_MAX23:
			gus.version = GUS_CARD_VERSION_MAX1;
			break;
		  case GUS_VER_ACE:
			gus.version = GUS_CARD_VERSION_ACE;
			break;
		  case GUS_VER_PNP:
			gus.interwave = 1;
			gus.version = GUS_CARD_VERSION_PNP;
			break;
		}

	if (UltraSizeDram(&gus.ram))
		gus.ram = 0;
	gus.freeram = gus.ram * 1024;

	return 0;
}

int gus_info(gus_info_t * info, int reread)
{
	if (!gus.open)
		return -1;

	strcpy(info->id, "gus0");
	info->flags = (gus.ram ? GUS_STRU_INFO_F_PCM : 0);
	info->version = gus.version;

	info->mixing_freq = gus.freq;

	info->memory_size = gus.ram * 1024;
	info->memory_free = info->memory_block_8 = info->memory_block_16 =
	  gus.freeram;
	return 0;
}

int gus_close(int card)
{
	if (!gus.open || card != gus.card)
		return -1;

	/* Reset the card */
	gus_reset(gus.voices, 0);

	/* Stop the timer */
	gus_timer_stop();

	gus.open--;

	/* Wait for timer1 thread to shut down */
	while (gus.tid) {
		UltraUnblockAll();
		DosSleep(1);
	}

	DosCloseEventSem(gus.cmd_pool_flushed);

	__gus_instruments_clear();
	UltraReleaseAccess();

	return 0;
}

int gus_select(int card)
{
	if (!gus.open || (card != gus.card))
		return -1;

	return 0;
}

/* return value:	same as gus_reset function
 * note:			this command doesn't change number of active
 *					voices and doesn't do hardware reset
 */
int gus_reset_engine_only()
{
	gus.t1_base = 100;
	return 0;
}

int gus_reset(int voices, unsigned int channel_voices)
{
	static unsigned short freq_table[32 - 14 + 1] = {
		44100, 41160, 38587, 36317, 34300, 32494, 30870, 29400, 28063, 26843,
		25725, 24696, 23746, 22866, 22050, 21289, 20580, 19916, 19293
	};
	int voice;

	/* No support for dynamically allocated voices for now */
	gus.dynmask = channel_voices;

	if (voices < 14)
		voices = 14;
	if (voices > 32)
		voices = 32;

	/* Stop all voices */
	for (voice = 0; voice < 32; voice++)
		UltraStopVoice(voice);

	if (gus.voices != voices) {
		gus.voices = voices;
		UltraSetNVoices(gus.voices);
	}

	/* Compute the discretization frequence */
	gus.voices = voices;
	if (gus.interwave)
		gus.freq = 44100;
	else
		gus.freq = freq_table[voices - 14];

	gus_reset_engine_only();

	return gus.voices;
}

int gus_do_flush()
{
	ULONG count;
	__gus_callback old_callback = NULL;

	DEBUG_PRINT(("gus_do_flush: top = %d\n", gus.cmd_pool_top));

	/* If gus.cmd_pool_ready. something went wrong */
	if (gus.cmd_pool_ready)
		return -1;

	/* If called from timer thread, don't block on event semaphore */
	if (_gettid() == gus.tid) {
		gus.cmd_pool_ready = 1;
		return 0;
	}

	/* If timer is not running, temporarily start it so that flush can happen */
	if (!gus.timer1) {
		old_callback = gus.t1_callback;
		UltraStartTimer(1, gus.t1_counter);
	}

	DosResetEventSem(gus.cmd_pool_flushed, &count);
	gus.cmd_pool_ready = 1;
	DosWaitEventSem(gus.cmd_pool_flushed, 1000);

	if (!gus.timer1) {
		UltraStopTimer(1);
		gus.t1_callback = old_callback;
	}

	if (gus.cmd_pool_ready)
		return -1;
	return 0;
}

/* set new tempo */
void gus_do_tempo(unsigned int tempo)
{
	DEBUG_PRINT(("gus_do_tempo (%d)\n", tempo));
	gus_timer_tempo(tempo);
	gus_timer_start();
}

/* set voice frequency in Hz */
void gus_do_voice_frequency(unsigned char voice, unsigned int freq)
{
	DEBUG_PRINT(("gus_do_voice_frequency (%d, %d)\n", voice, freq));
	__pool_select_voice(voice);
	__pool_command_w(PCMD_FREQ, freq);
}

/* set voice pan (0-16384) (full left - full right) */
void gus_do_voice_pan(unsigned char voice, unsigned short pan)
{
	DEBUG_PRINT(("gus_do_voice_pan (%d, %d)\n", voice, pan));
	pan >>= 10;
	if (pan > 15)
		pan = 15;
	__pool_select_voice(voice);
	__pool_command_b(PCMD_PAN, pan);
}

/* set voice volume level 0-16384 (linear) */
void gus_do_voice_volume(unsigned char voice, unsigned short vol)
{
	DEBUG_PRINT(("gus_do_voice_volume (%d, %d)\n", voice, vol));
	if (vol > 0x3fff)
		vol = 0x3fff;
	__pool_select_voice(voice);
	__pool_command_w(PCMD_VOLUME, vol >> 5);
}

/* start voice
 *   voice    : voice #
 *   program  : program # or ~0 = current
 *   freq     : frequency in Hz
 *   volume   : volume level (0-16384) or ~0 = current
 *   pan      : pan level (0-16384) or ~0 = current
 */
void gus_do_voice_start(unsigned char voice, unsigned int program,
						unsigned int freq, unsigned short volume,
						unsigned short pan)
{
	gus_do_voice_start_position(voice, program, freq, volume, pan, 0);
}

/* start voice
 *   voice    : voice #
 *   program  : program # or ~0 = current
 *   freq     : frequency in Hz
 *   volume   : volume level (0-16384) or ~0 = current
 *   pan      : pan level (0-16384) or ~0 = current
 *   position : offset to wave in bytes * 16 (lowest 4 bits - fraction)
 */
void gus_do_voice_start_position(unsigned char voice, unsigned int program,
								 unsigned int freq, unsigned short volume,
								 unsigned short pan, unsigned int position)
{
	gus_instrument_t *instrument;
	gus_wave_t *wave;

	DEBUG_PRINT(("gus_do_voice_start_position (%d, %d, pos: %d)\n", voice,
				 program, position));

	instrument = __gus_instrument_get(program);

	if (!instrument
		|| !instrument->info.layer
		|| !instrument->info.layer->wave
		|| instrument->flags == GUS_INSTR_F_NOT_FOUND
		|| instrument->flags == GUS_INSTR_F_NOT_LOADED) return;

	gus_do_voice_frequency(voice, freq);
	gus_do_voice_pan(voice, pan);
	gus_do_voice_volume(voice, volume);

	switch (instrument->mode) {
	  case GUS_INSTR_SIMPLE:
		wave = instrument->info.layer->wave;
		if (position)
			__pool_command_l(PCMD_OFFSET, position);
		__pool_command_l(PCMD_START, (unsigned long)wave);
		break;
	}
}

/* stop voice
 *   mode = 0 : stop voice now
 *   mode = 1 : disable wave loop and finish it
 */
void gus_do_voice_stop(unsigned char voice, unsigned char mode)
{
	__pool_select_voice(voice);
	if (mode)
		__pool_command(PCMD_STOP_LOOP);
	else
		__pool_command(PCMD_STOP);
}

/* wait x ticks - this command is block separator
 * all commands between blocks are interpreted in the begining of one tick
 */
void gus_do_wait(unsigned int ticks)
{
	ULONG count;

	DEBUG_PRINT(("gus_do_wait (%d)\n", ticks));

	DosResetEventSem(gus.wait_finished, &count);
	gus.wait_count = ticks;
	DosWaitEventSem(gus.wait_finished, 1000);
	return;
}

int gus_get_voice_status(int voice)
{
	if (UltraVoiceStopped(&voice))
		return -1;
	return voice & VOICE_STOPPED ? 0 : 1;
}

/* return value:      file handle (descriptor) for /dev/gus */
int gus_get_handle()
{
	int handle;
	UltraGetHandle(&handle);
	return handle;
}

/* return value:      zero if instrument was successfully allocated */
int gus_memory_alloc(gus_instrument_t * instrument)
{
	gus_instrument_t *instr = __gus_instrument_copy(instrument);
	gus_layer_t *cur_layer;
	gus_wave_t *cur_wave;

	DEBUG_PRINT(("gus_memory_alloc (%d)\n", instrument->number.instrument));

	if (!instr)
		return -1;

	for (cur_layer = instr->info.layer; cur_layer;
		 cur_layer = cur_layer->next) for (cur_wave = cur_layer->wave;
										   cur_wave;
										   cur_wave = cur_wave->next) {
			if (cur_layer->mode == GUS_INSTR_SIMPLE) {
				unsigned char dlctl = 0;

				if (UltraMemAlloc
					(cur_wave->size, (unsigned long *)&cur_wave->begin.memory,
					 gus.interwave ? 0 : ((cur_wave->format & GUS_WAVE_16BIT)
										  != 0))) {
					cur_wave->begin.memory = -1;
					__gus_instrument_free(instr);
					return -1;
				}
				gus.freeram -= cur_wave->size;

				if (cur_wave->format & GUS_WAVE_16BIT)
					dlctl |= DMA_16;
				if (cur_wave->format & GUS_WAVE_INVERT)
					dlctl |= DMA_CVT_2;

				UltraDownload(cur_wave->begin.ptr, dlctl,
							  cur_wave->begin.memory, cur_wave->size, FALSE);
			} else if (cur_layer->mode == GUS_INSTR_PATCH)
				/* not supported yet */ ;
		}

	return 0;
}

/* return value:      zero if instrument was successfully removed */
int gus_memory_free(gus_instrument_t * instrument)
{
	gus_instrument_t *cur_instr = gus.instr;

	DEBUG_PRINT(("gus_memory_free (%d)\n", instrument->number.instrument));

	for (; cur_instr; cur_instr = cur_instr->next)
		if (cur_instr->number.instrument == instrument->number.instrument)
			return __gus_instrument_free(cur_instr);

	return -1;
}

/* return value:      unused gus memory in bytes */
int gus_memory_free_size()
{
	return gus.freeram;
}

/* return value:      zero if success */
int gus_memory_pack()
{
	/* not implemented */
	return 0;
}

/* return value:	gus memory size in bytes */
int gus_memory_size()
{
	return gus.ram * 1024;
}

/* return value:	current largest free block for 8-bit or 16-bit wave */
int gus_memory_free_block(int w_16bit)
{
	return gus.freeram;
}

/* input value:	see to GUS_DOWNLOAD_MODE_XXXX constants (gus.h)
 * return value:	zero if samples & instruments was successfully removed
 *					from GF1 memory manager
 */
int gus_memory_reset(int mode)
{
	UltraMemInit();
	gus.freeram = gus.ram * 1024;
	__gus_instruments_clear();
	return 0;
}

/* return value:      zero if command queue was successfully flushed */
int gus_queue_flush()
{
	return 0;
}

/* input value:       echo buffer size in items (if 0 - erase echo buffer) */
int gus_queue_read_set_size(int items)
{
	return 0;
}

/* input value:       write queue size in items (each item have 8 bytes) */
int gus_queue_write_set_size(int items)
{
	return 0;
}

/* return value:      zero if successfull */
int gus_timer_start()
{
	if (!gus.timer1) {
		gus.timer1 = TRUE;
		UltraStartTimer(1, gus.t1_counter);
	}
	return 0;
}

/* return value:      zero if timer was stoped */
int gus_timer_stop()
{
	if (gus.timer1) {
		gus.timer1 = FALSE;
		UltraStopTimer(1);
	}
	return 0;
}

/* return value:      zero if setup was success */
int gus_timer_tempo(int ticks)
{
	unsigned int counter;

	/* Limit ticks per second to 1..1000 range */
	if (ticks < 1)
		ticks = 1;
	if (ticks > 1000)
		ticks = 1000;

	/* GF1 timer1 period is 80 usecs, 12500 times per second */
	counter = 1250000 / (ticks * gus.t1_base);
	gus.t1_multiple = 1;
	while (counter > 255) {
		counter >>= 1;
		gus.t1_multiple <<= 1;
	}
	gus.t1_countdown = gus.t1_multiple;
	gus.t1_counter = counter;
	gus_timer_stop();
	gus_timer_start();
	return 0;
}

/* return value:	zero if timer will be continue */
int gus_timer_continue()
{
	return gus_timer_start();
}

/* return value:	zero if setup was success (default timebase = 100) */
int gus_timer_base(int base)
{
	gus.t1_base = base;
	return 0;
}

void gus_timer_callback(void (*timer_callback) ())
{
	gus.t1_callback = timer_callback;
}

void gus_convert_delta(unsigned int type, unsigned char *dest,
					   unsigned char *src, size_t size)
{
	if (!(type & GUS_WAVE_DELTA))
		return;

	/* This doesn't depend much on wave signedness, since
	 * addition/subtraction do not depend on operand signedness
	 */
	if (type & GUS_WAVE_16BIT) {
		unsigned short delta = type & GUS_WAVE_UNSIGNED ? 0x8000 : 0;
		while (size--) {
			delta = *(unsigned short *)dest = *(unsigned short *)src + delta;
			src += sizeof(unsigned short);
			dest += sizeof(unsigned short);
		}
	} else {
		unsigned char delta = type & GUS_WAVE_UNSIGNED ? 0x80 : 0;
		while (size--) {
			delta = *(unsigned char *)dest = *(unsigned char *)src + delta;
			src++;
			dest++;
		}
	}
}

/* ex:set ts=4: */
